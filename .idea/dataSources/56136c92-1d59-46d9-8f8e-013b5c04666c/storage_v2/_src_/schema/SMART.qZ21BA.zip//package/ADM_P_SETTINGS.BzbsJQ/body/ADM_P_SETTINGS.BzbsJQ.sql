create package body adm_p_settings is

    -- Чтение параметра типа number
    function get_num (p_param varchar2) return number is
        v_result adm_settings.num_value%type;
    begin
        select
            num_value
        into
            v_result
        from
            adm_settings
        where
            name = lower(p_param);
        return v_result;
    exception
        when no_data_found then raise_application_error(-20000, 'Не найден параметр ' || lower(p_param));
    end get_num;


    -- Чтение параметра типа varchar2
    function get_str (p_param varchar2) return varchar2 is
        v_result adm_settings.str_value%type;
    begin
        select
            str_value
        into
            v_result
        from
            adm_settings
        where
            name = lower(p_param);
        return v_result;
    exception
        when no_data_found then raise_application_error(-20000, 'Не найден параметр ' || lower(p_param));
    end get_str;


    -- Чтение параметра типа date
    function get_date (p_param varchar2) return date is
        v_result adm_settings.date_value%type;
    begin
        select
            date_value
        into
            v_result
        from
            adm_settings
        where
            name = lower(p_param);
        return v_result;
    exception
        when no_data_found then raise_application_error(-20000, 'Не найден параметр ' || lower(p_param));
    end get_date;

end adm_p_settings;

/

