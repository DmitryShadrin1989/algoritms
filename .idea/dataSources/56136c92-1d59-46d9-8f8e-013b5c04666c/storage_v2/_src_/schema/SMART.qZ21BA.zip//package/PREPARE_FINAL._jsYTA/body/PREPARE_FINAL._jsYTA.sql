create package body prepare_final is

c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Расчет финальных данных для backend по продажам
procedure calculate_final_sales_ware_by_day as
    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_final_sales_ware_by_day');
begin

    log.trace('Удаляем записи из финальной таблицы на дату');

    -- Удаляем записи из финальной таблицы на дату
    delete from
        final_sales_ware_by_day c;

    log.trace('Добавляем новые записи на дату');

    -- Добавляем новые записи на дату
    insert into
        final_sales_ware_by_day
            (
                doc_id,
                change_id,
                ts_update,
                id_category,
                category,
                id_subcategory_mfp,
                subcategory_mfp,
                id_subcategory_ap,
                subcategory_ap,
                id_class,
                class,
                id_subclass,
                subclass,
                day,
                week,
                month,
                id_sellers,
                sellers,
                id_ware,
                trade_mark,
                name,
                article,
                schema,
                net_sales_r,
                net_sales_u
            )
    select
        seq_doc_id.nextval,
        seq_change_id.nextval,
        current_timestamp,
        tn.id_category,
        tn.category,
        tn.id_subcategory_mfp,
        tn.subcategory_mfp,
        tn.id_subcategory_ap,
        tn.subcategory_ap,
        tn.id_class,
        tn.class,
        tn.id_subclass,
        tn.subclass,
        trunc(sr.day),
        concat(to_char(sr.day,'YYYY'), concat(concat('-',to_char(sr.day,'IW')),'W' )),
        concat(to_char(sr.day,'YYYY'), concat(concat('-',to_char(sr.day,'MM')),'M' )),
        sr.id_sellers,
        s.name_rus,
        sr.id_ware,
        sw.trade_mark,
        sw.name,
        sw.article,
        'FBSM',
        sr.net_sales_r,
        sr.net_sales_u
    from
        prcs_merchant_sales_returns sr
    left join
        mdm_sellers s
    on
        s.id_sellers = sr.id_sellers
    left join
        mdm_sellers_ware sw
    on
        sw.id_ware = sr.id_ware
    left join
        mdm_ware_prod_rdapgen tn
    on
        tn.id_ware = sr.id_ware;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_final_sales_ware_by_day;

-- Расчет финальных данных для backend по оборотам продаж
procedure calculate_final_turnover_by_day (
    p_day date default trunc(sysdate) - numtodsinterval(1, 'day')
) as
    v_day date := p_day;
    v_count number;
    v_week_minus_3_start date;
    v_week_minus_3_end date;
    v_week_minus_2_start date;
    v_week_minus_2_end date;
    v_prev_week_start date;
    v_prev_week_end date;
    v_this_week_start date;
    v_this_week_end date;
    v_number_day_in_week number;
    v_stock_date date;

    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_final_turnover_by_day',
        p_proc_param => 'p_date =>' || p_day);
begin
    log.trace('Проверка, что на указанную дату еще нет расчета');

    select
       count(*)
    into
       v_count
    from
        final_turnover_by_day t
    where
        t.day = v_day;

    if v_count > 0 then
        raise_application_error(c_stack_info_error, log.error_result(), true);
        return;
    end if;

    log.trace('Инициируем переменные');

    select
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(27, 'day') as week_minus_3_start,
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(21, 'day') as week_minus_3_end,
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(20, 'day') as week_minus_2_start,
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(14, 'day') as week_minus_2_end,
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(13, 'day') as prev_week_start,
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(7, 'day')  as prev_week_end,
        to_date(c.week_code, 'yyyymmdd') - numtodsinterval(6, 'day')  as this_week_start,
        to_date(c.week_code, 'yyyymmdd')                              as this_week_end,
        to_number(substr(c.day_week_code, 4))
    into
        v_week_minus_3_start,
        v_week_minus_3_end,
        v_week_minus_2_start,
        v_week_minus_2_end,
        v_prev_week_start,
        v_prev_week_end,
        v_this_week_start,
        v_this_week_end,
        v_number_day_in_week
    from
        isp_calendar_mfp_sm c
    where
        c.day_code = to_char(v_day, 'yyyymmdd')
    ;

    select
        max(s.day) as stock_day
    into
        v_stock_date
    from
        prcs_merchant_stock s
    where
        s.day <= v_day
    ;

    log.trace('Выполняем основной расчет');

    insert into
        final_turnover_by_day t
            (
                doc_id,
                change_id,
                ts_update,
                id_category,
                category,
                id_subcategory_mfp,
                subcategory_mfp,
                id_subcategory_ap,
                subcategory_ap,
                id_class,
                class,
                id_subclass,
                subclass,
                day,
                id_sellers,
                sellers,
                id_ware,
                trade_mark,
                name,
                article,
                schema,
                week_3,
                week_2,
                lw,
                tw,
                weeks_4,
                stock_u,
                stock_u_oh,
                approx_stock_date,
                delivery_u,
                delivery_r,
                turnover,
                rec_order_u
            )
    with slice_last_stock as -- Остатки на дату
        (
            select
                s.id_ware,
                s.id_sellers,
                s.stock_u,
                s.stock_u_oh
            from
                prcs_merchant_stock s
            where
                s.day = v_stock_date
        )
    , weeks_4 as -- Обророт по продажам за 4е недели
        (
            select
                sr.id_ware,
                sr.id_sellers,
                sum(sr.net_sales_u) as sum_u
            from
                prcs_merchant_sales_returns sr
            where
                sr.day between v_week_minus_3_start and v_day
            group by
                sr.id_ware,
                sr.id_sellers
        )
    , ware_sellers as -- Собираем основную таблицу, к которой будут делаться left join остальных данных
        (
            select
                s.id_ware,
                s.id_sellers
            from
                slice_last_stock s
            union
            select
                w4.id_ware,
                w4.id_sellers
            from
                weeks_4 w4
        )
    , week_minus_3 as -- Оборот по прожам за третью неделю
        (
            select
                sr.id_ware,
                sr.id_sellers,
                sum(sr.net_sales_u) as sum_u
            from
                prcs_merchant_sales_returns sr
            where
                sr.day between v_week_minus_3_start and v_week_minus_3_end
            group by
                sr.id_ware,
                sr.id_sellers
        )
    , week_minus_2 as -- Оборот по прожам за вторую неделю
        (
            select
                sr.id_ware,
                sr.id_sellers,
                sum(sr.net_sales_u) as sum_u
            from
                prcs_merchant_sales_returns sr
            where
                sr.day between v_week_minus_2_start and v_week_minus_2_end
            group by
                sr.id_ware,
                sr.id_sellers
        )
    , last_week as -- Оборот по прожам за предыдущую неделю
        (
            select
                sr.id_ware,
                sr.id_sellers,
                sum(sr.net_sales_u) as sum_u
            from
                prcs_merchant_sales_returns sr
            where
                sr.day between v_prev_week_start and v_prev_week_end
            group by
                sr.id_ware,
                sr.id_sellers
        )
    , this_week as -- Оборот по прожам за текущую неделю
        (
            select
                sr.id_ware,
                sr.id_sellers,
                sum(sr.net_sales_u) as sum_u
            from
                prcs_merchant_sales_returns sr
            where
                sr.day between v_this_week_start and v_day
            group by
                sr.id_ware,
                sr.id_sellers
        )
    select
        seq_doc_id.nextval,
        seq_change_id.nextval,
        current_timestamp,
        wpr.id_category,
        wpr.category,
        wpr.id_subcategory_mfp,
        wpr.subcategory_mfp,
        wpr.id_subcategory_ap,
        wpr.subcategory_ap,
        wpr.id_class,
        wpr.class,
        wpr.id_subclass,
        wpr.subclass,
        v_day,
        ws.id_sellers,
        sw.sellers,
        ws.id_ware,
        sw.trade_mark,
        sw.name,
        sw.article,
        'FBSM',
        w3.sum_u,
        w2.sum_u,
        lw.sum_u,
        tw.sum_u,
        w4.sum_u,
        slt.stock_u,
        slt.stock_u_oh,
        case
            when v_stock_date <> v_day then v_stock_date -- Если дата остатка отличается от дня на который выполняется расчет,
            else null                                    -- то значение approx_stock_date будет заполнено этой датой, иначе NULL
        end,
        null,
        null,
        get_turnover -- Расчет оборачиваемости
            (
                slt.stock_u,
                w3.sum_u,
                w2.sum_u,
                lw.sum_u,
                tw.sum_u,
                v_number_day_in_week
            ),
        get_recommended_order -- Расчет рекомендованного заказа
            (
                slt.stock_u,
                w3.sum_u,
                w2.sum_u,
                lw.sum_u,
                tw.sum_u,
                0
            )
    from
        ware_sellers ws
    left join
        mdm_ware_prod_rdapgen wpr
    on
        wpr.id_ware = ws.id_ware
    left join
        mdm_sellers_ware sw
    on
        sw.id_ware = ws.id_ware
    left join
        week_minus_3 w3
    on
        w3.id_ware = ws.id_ware
        and w3.id_sellers = ws.id_sellers
    left join
        week_minus_2 w2
    on
        w2.id_ware = ws.id_ware
        and w2.id_sellers = ws.id_sellers
    left join
        last_week lw
    on
        lw.id_ware = ws.id_ware
        and lw.id_sellers = ws.id_sellers
    left join
        this_week tw
    on
        tw.id_ware = ws.id_ware
        and tw.id_sellers = ws.id_sellers
    left join
        weeks_4 w4
    on
        w4.id_ware = ws.id_ware
        and w4.id_sellers = ws.id_sellers
    left join
        slice_last_stock slt
    on
        slt.id_ware = ws.id_ware
        and slt.id_sellers = ws.id_sellers
    ;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_final_turnover_by_day;

-- Расчет оборачиваемости
function get_turnover
    (
        p_stock_u number,
        p_week_3 number,
        p_week_2 number,
        p_last_week number,
        p_this_week number,
        p_number_day_in_week number
    )
return number is
    v_stock_u number := nvl(p_stock_u, 0);
    v_week_3 number := nvl(p_week_3, 0);
    v_week_2 number := nvl(p_week_2, 0);
    v_last_week number := nvl(p_last_week, 0);
    v_this_week number := nvl(p_this_week, 0);
    v_number_day_in_week number := p_number_day_in_week;

    v_denominator number;
    v_result number;
begin

    v_denominator := v_week_3 * 0.4 + v_week_2 * 0.8 + v_last_week * 1.2 + v_this_week * 1.6;

    if v_denominator <> 0 then
        v_result := (v_stock_u / v_denominator) * (21 + v_number_day_in_week);
    else
        v_result := null;
    end if;

    return floor(v_result);
exception
    when others then raise_application_error(-20000, 'Ошибка при расчете оборачивемости');
end get_turnover;

-- Расчет рекомендованного заказа
function get_recommended_order
    (
        p_stock_u number,
        p_week_3 number,
        p_week_2 number,
        p_last_week number,
        p_this_week number,
        p_delivery_u number
    )
return number is
    v_stock_u number := nvl(p_stock_u, 0);
    v_week_3 number := nvl(p_week_3, 0);
    v_week_2 number := nvl(p_week_2, 0);
    v_last_week number := nvl(p_last_week, 0);
    v_this_week number := nvl(p_this_week, 0);
    v_delivery_u number := nvl(p_delivery_u, 0);

    v_result number;
begin
    v_result := (v_week_3 * 0.4 + v_week_2 * 0.8 + v_last_week * 1.2 + v_this_week * 1.6) - v_stock_u - v_delivery_u;

    if v_result > 0 then
        return ceil(v_result);
    end if;

    return 0;
exception
    when others then raise_application_error(-20000, 'Ошибка при расчете рекомендованного заказа');
end get_recommended_order;

-- Расчет финальных данных для backend брендам
procedure calculate_final_brand_by_day as
    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_final_brand_by_day');
begin

    log.trace('Удаляем записи из финальной таблицы на дату');

    -- Удаляем записи из финальной таблицы на дату
    delete from
        final_brand_by_day c;

    log.trace('Добавляем новые записи на дату');

    -- Добавляем новые записи на дату
    insert into
        final_brand_by_day
            (
                doc_id,
                change_id,
                ts_update,
                id_category,
                category,
                trade_mark,
                id_sellers,
                sellers,
                id_schema,
                schema,
                day,
                sales_r,
                sales_u
            )
    with b as
    (
        select
            wpr.id_category,
            wpr.category,
            w.trade_mark,
            st.id_sellers,
            w.sellers,
            st.id_channel as id_schema,
            day,
            sum(net_sales_r) as sales_r,
            sum(net_sales_u) as sales_u
        from
            prcs_merchant_sales_returns st
        join
            mdm_ware_prod_rdapgen wpr
        on
            wpr.id_ware = st.id_ware
        join
            mdm_sellers_ware w
        on
            w.id_ware = st.id_ware
        group by
            day,
            st.id_sellers,
            wpr.id_category,
            wpr.category,
            w.trade_mark,
            w.sellers,
            st.id_channel
    )
    select
        seq_doc_id.nextval,
        seq_change_id.nextval,
        current_timestamp,
        b.id_category,
        b.category,
        b.trade_mark,
        b.id_sellers,
        b.sellers,
        b.id_schema,
        case b.id_schema
            when 1 then 'FBSM'
            when 2 then 'FBS'
            when 3 then 'DBS'
            when 4 then 'CB'
        end as schema,
        b.day,
        b.sales_r,
        b.sales_u
    from
        b
    ;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_final_brand_by_day;

end prepare_final;

/

