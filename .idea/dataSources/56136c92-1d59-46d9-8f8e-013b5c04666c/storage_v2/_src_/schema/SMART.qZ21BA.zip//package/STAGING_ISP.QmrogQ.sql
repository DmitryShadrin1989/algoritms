create package staging_isp is

-- Начало загрузки данных из ИПР
procedure start_load;

-- Конец загрузки/выгрузки данных из/в ИПР
procedure end_load;

-- Полная загрузка Календарной иерархии SM MFP(из Календарного модуля BC)
procedure full_download_calendar_mfp_sm;  

end staging_isp;
/

