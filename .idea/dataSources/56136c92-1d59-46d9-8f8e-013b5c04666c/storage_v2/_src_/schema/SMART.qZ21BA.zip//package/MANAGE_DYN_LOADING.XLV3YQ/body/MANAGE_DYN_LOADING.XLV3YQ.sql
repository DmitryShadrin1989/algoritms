create package body manage_dyn_loading is

c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Загрузка данных по настройке
procedure loading_table_data
(
    p_id_table number  -- Идентификатор сущности    
) as
    log proc_log_t := proc_log_t.init('loading_entity_data');
    
    v_command_delete        varchar2(4000) := 'delete from target_table';
    v_command_insert        varchar2(4000) := 'insert into target_table (target_column)'
        || 'select source_column from source_table';
    v_target_table          varchar2(4000); 
    v_source_table          varchar2(4000);
    v_condition             varchar2(4000); 
    v_column_target_table   varchar2(4000);
    v_column_source_table   varchar2(4000);
begin
  
    log.trace('Fill in the target table, source and condition from the saved settings');
    
    -- Заполняем из сохраненной настройки целевую таблицу, источник и условие
    select
        s.target_table,
        s.source_table,
        s.condition
    into
        v_target_table,
        v_source_table,
        v_condition   
    from 
        adm_dyn_loading_tables s
    where
        s.id_table = p_id_table;
        
    -- Заполняем из сохраненной настройки поля целевой таблицы и источника
    for l in
        (
            select
                s.column_target_table as column_target_table,
                s.column_source_table as column_source_table         
            from 
                adm_dyn_loading_table_cols s
            where
                s.id_table = p_id_table  
        )
    loop
        if v_column_target_table is not null then
            v_column_target_table := v_column_target_table || ', ';
            v_column_source_table := v_column_source_table || ', ';
        end if;  
        v_column_target_table := v_column_target_table || l.column_target_table;
        v_column_source_table := v_column_source_table || l.column_source_table;
    end loop;
    
    -- Склеиваем и выполняем команду для удаления
    v_command_delete := replace(v_command_delete, 'target_table', v_target_table);
       
    execute immediate v_command_delete;
    
    -- Склеиваем и выполняем команду для вставки      
    v_command_insert := replace(v_command_insert, 'target_table', v_target_table);
    v_command_insert := replace(v_command_insert, 'source_table', v_source_table);
    v_command_insert := replace(v_command_insert, 'target_column', v_column_target_table);
    v_command_insert := replace(v_command_insert, 'source_column', v_column_source_table);
    v_command_insert := v_command_insert || ' ' || v_condition;     
        
    execute immediate v_command_insert;    

    commit;
    
    log.success_result;
  
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end loading_table_data;

-- Загрузка данных по группе настроек
procedure loading_group_table_data
(
    p_group_name varchar2  -- Группа настроек
) as
    log proc_log_t := proc_log_t.init('loading_group_table_data');
begin
  
    log.trace('We get the loading settings by group, with selection by the is_active field and sort by priority');
    
    for l in
        (
            select
                s.id_table 
            from 
                adm_dyn_loading_tables s
            where
                s.group_setting = p_group_name
                and s.is_activ = 1
            order by
                s.priority
        )
    loop
        loading_table_data(p_id_table => l.id_table);
    end loop;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end loading_group_table_data;
 
end manage_dyn_loading;
/

