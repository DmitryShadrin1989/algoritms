create package body processing is

c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Расчет остатков товаров мерчантов на дату
procedure calculate_merchant_stock_on_date
(
    p_date_stock date
) as
    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_merchant_stock_on_date', p_proc_param => 'p_date_stock =>' || p_date_stock);
begin

    log.trace('Удаляем записи на дату');

    delete from
        prcs_merchant_stock pm
    where
        pm.day = trunc(p_date_stock);

    log.trace('Добавляем новые записи по остаткам');

    insert into
        prcs_merchant_stock pm
            (
                pm.change_id,
                pm.ts_update,
                pm.day,
                pm.id_ware,
                pm.id_sellers,
                pm.stock_u,
                pm.stock_u_oh
            )
    with mm as
        (
            select
                id_ware,
                id_sellers,
                sum(quantity) as stock_u
            from
                mks_merchant_stock_data
            where
                trunc(balance_date) = trunc(p_date_stock)
            group by
                id_ware,
                id_sellers
        )
    , mm_oh as
        (
            select
                id_ware,
                id_sellers,
                sum(quantity) as stock_u_oh
            from
                mks_merchant_stock_data
            where
                trunc(balance_date) = trunc(p_date_stock)
                and stock_type = adm_p_settings.get_str(p_param => 'stock_type_oh')
            group by
                id_ware,
                id_sellers
        )
    select
        seq_change_id.nextval,
        current_timestamp,
        trunc(p_date_stock),
        mm.id_ware,
        mm.id_sellers,
        mm.stock_u,
        mm_oh.stock_u_oh
    from
        mm
    left join
        mm_oh
    on
        mm_oh.id_ware = mm.id_ware
        and mm_oh.id_sellers = mm.id_sellers
    ;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_merchant_stock_on_date;

-- Расчет остатков товаров мерчантов
procedure calculate_merchant_stocks as
    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_merchant_stocks');
begin

    log.trace('Получаем даты в которых не актуальная калькуляция остатков, в качестве признака используем поле change_id');

    for l in
        (
            with mm as
                (
                    select
                        trunc(balance_date) as day,
                        max(change_id) as change_id
                    from
                        mks_merchant_stock_data
                    group by
                        balance_date
                )
            , pm as
                (
                    select
                        day,
                        max(change_id) as change_id
                    from
                        prcs_merchant_stock
                    group by
                        day
                )
            select
                mm.day
            from
                mm,
                pm
            where
                mm.day = pm.day
                and mm.change_id > pm.change_id
            union
            select
                mm.day
            from
                mm
            where
                mm.day not in
                    (
                        select
                            pm.day
                        from
                            pm
                    )
        )
    loop
        -- Запускаем расчет калькуляции на каждую дату
        calculate_merchant_stock_on_date(p_date_stock => l.day);
    end loop;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_merchant_stocks;

-- Расчет данных по продажам и возвратам на дату
procedure calculate_merchant_sales_returns_on_date
(
    p_date_sales_returns date
) as
    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_merchant_sales_returns_on_date',
        p_proc_param => 'p_date_sales_returns =>' || p_date_sales_returns);
begin

    log.trace('Удаляем записи на дату');

    delete from
        prcs_merchant_sales_returns pm
    where
        pm.day = trunc(p_date_sales_returns);

    log.trace('Добавляем новые записи по продажам и возвратам');

    insert into
        prcs_merchant_sales_returns pm
            (
                pm.change_id,
                pm.ts_update,
                pm.day,
                pm.id_ware,
                pm.id_sellers,
                pm.id_channel,
                pm.gross_sales_r,
                pm.gross_sales_u,
                pm.net_sales_r,
                pm.net_sales_u,
                pm.returns_r,
                pm.returns_u,
                pm.markdown_r
            )
    with s as
        (
            select
                s.id_ware,
                s.id_sellers,
                sum(s.price) as gross_sales_r,
                sum(s.quantity) as gross_sales_u,
                sum(s.discont_summa) as markdown_r
            from
                compro_goods_sale s
            where
                s.status = 1
                and trunc(s.release_ts) = trunc(p_date_sales_returns)
            group by
               id_ware,
               id_sellers
       )
    , r as
        (
            select
                r.id_ware,
                r.id_sellers,
                sum(r.refund_amount) as returns_r ,
                sum(r.quantity) as returns_u
            from
                compro_goods_returns r
            where
                r.status = 1
                and trunc(r.basket_date) = trunc(p_date_sales_returns)
            group by
               id_ware,
               id_sellers
       )
    , u as
        (
            select
                s.id_ware,
                s.id_sellers,
                s.gross_sales_r,
                s.gross_sales_u,
                0 as returns_r,
                0 as returns_u,
                s.markdown_r
            from
                s
            union all
            select
                r.id_ware,
                r.id_sellers,
                0 as gross_sales_r,
                0 as gross_sales_u,
                r.returns_r,
                r.returns_u,
                0 as markdown_r
            from
                r
        )
    , i as
        (
            select
                u.id_ware,
                u.id_sellers,
                sum(u.gross_sales_r) as gross_sales_r,
                sum(u.gross_sales_u) as gross_sales_u,
                sum(u.returns_r) as returns_r,
                sum(u.returns_u) as returns_u,
                sum(u.markdown_r) as markdown_r
            from
                u
            group by
                u.id_ware,
                u.id_sellers
        )
    select
        seq_change_id.nextval,
        current_timestamp,
        trunc(p_date_sales_returns),
        i.id_ware,
        i.id_sellers,
        1 as id_channel,
        i.gross_sales_r,
        i.gross_sales_u,
        i.gross_sales_r - i.returns_r as net_sales_r,
        i.gross_sales_u - i.returns_u as net_sales_u,
        i.returns_r,
        i.returns_u,
        i.markdown_r
    from
        i;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_merchant_sales_returns_on_date;

-- Расчет данных по продажам и возвратам
procedure calculate_merchant_sales_returns as
    log proc_log_t := proc_log_t.init(p_proc_name => 'calculate_merchant_sales_returns');
begin

    log.trace('Получаем даты в которых не актуальная калькуляция данных по продажам и возвратам,'
        || 'в качестве признака используем поле change_id');

    for l in
        (
            with s as -- Получаем максимальное значение change_id на дату по продажам
                (
                    select
                        trunc(s.release_ts) as day,
                        max(s.change_id) as change_id
                    from
                        compro_goods_sale s
                    where
                        s.status = 1
                    group by
                        trunc(s.release_ts)
                )
            , r as -- Получаем максимальное значение change_id на дату по возвратам
                (
                    select
                        trunc(r.basket_date ) as day,
                        max(r.change_id) as change_id
                    from
                        compro_goods_returns r
                    where
                        r.status = 1
                    group by
                        trunc(r.basket_date )
                )
            , pm as -- Получаем максимальное значение change_id на дату по калькуляции
                (
                    select
                        day,
                        max(change_id) as change_id
                    from
                        prcs_merchant_sales_returns
                    group by
                        day
                )
            select
                s.day
            from
                s
            join
                pm
            on
                pm.day = s.day
                and pm.change_id < s.change_id
            union
            select
                s.day
            from
                s
            where
                s.day not in
                    (
                        select
                            pm.day
                        from
                            pm
                    )
            union
            select
                r.day
            from
                r
            join
                pm
            on
                pm.day = r.day
                and pm.change_id <r.change_id
            union
            select
                r.day
            from
                r
            where
                r.day not in
                    (
                        select
                            pm.day
                        from
                            pm
                    )
        )
    loop
        -- Запускаем расчет калькуляции на каждую дату
        calculate_merchant_sales_returns_on_date(p_date_sales_returns => l.day);
    end loop;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end calculate_merchant_sales_returns;

end processing;

/

