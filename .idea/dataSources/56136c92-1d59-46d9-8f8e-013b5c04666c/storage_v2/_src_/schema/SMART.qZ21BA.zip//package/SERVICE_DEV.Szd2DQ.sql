create package service_dev is

-- Загрузка данных c Прода
procedure copy_data_from_prod;

end service_dev;

/

