create view V_SALES as
with tree_node as
    (
        select
            great_child_node,
            category,
            subcategory_mfp,
            subcategory_ap,
            class,
            subclass
        from
            (
                select
                    connect_by_root t.id_node as great_child_node,
                    t.moniker_rus,
                    t.level_num
                from
                    mdm_tree_nodes_prod_rdapgen t
                start with t.id_node in
                    (
                        select
                            ts.id_node
                        from
                            mdm_tree_nodes_prod_rdapgen ts
                        join
                            mdm_link_ware_tree_prod_rdapgen lt
                        on
                            lt.id_node = ts.id_node
                            and ts.level_num = 8
                    )
                connect by prior t.id_parent = t.id_node
            )
            pivot
            (
                max(moniker_rus)
                for level_num in
                    (
                        4 as category,
                        5 as subcategory_mfp,
                        6 as subcategory_ap,
                        7 as class,
                        8 as subclass
                    )
            )
    )
select
    rownum as id,
    tn.category,
    tn.subcategory_mfp,
    tn.subcategory_ap,
    tn.class,
    tn.subclass,
    sr.day,
    concat(to_char(sr.day,'YYYY'), concat(concat('-',to_char(sr.day,'IW')),'W' )) as week,
    concat(to_char(sr.day,'YYYY'), concat(concat('-',to_char(sr.day,'MM')),'M' )) as month,
    sr.id_sellers,
    s.name_rus as sellers,
    sr.id_ware,
    sw.trade_mark,
    sw.name,
    sw.article,
    'FBSM' as schema,
    sr.net_sales_r,
    sr.net_sales_u
from
    prcs_merchant_sales_returns sr
left join
    mdm_sellers s
on
    s.id_sellers = sr.id_sellers
left join
    mdm_sellers_ware sw
on
    sw.id_ware = sr.id_ware
left join
    mdm_link_ware_tree_prod_rdapgen lwt
on
    lwt.id_ware = sw.id_ware
left join
    tree_node tn
on
    tn.great_child_node = lwt.id_node
/

