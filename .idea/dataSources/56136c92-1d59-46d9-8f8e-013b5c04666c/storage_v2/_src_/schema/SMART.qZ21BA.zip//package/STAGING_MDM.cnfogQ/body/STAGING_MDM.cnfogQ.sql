create package body staging_mdm is

    c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

--  Авторизация в MDM
procedure mdm_authorize is
    log proc_log_t := proc_log_t.init('mdm_authorize');
begin

    log.trace('Авторизация в МДМ');

    pk_mdm_api_edit_entity.authorize@mskkis.world
        (
            a_user        => adm_p_settings.get_str('mdm_user'),
            a_password    => adm_p_settings.get_str('mdm_password'),
            a_is_internal => 'N'               -- признак внутренного пользователя
        );

    log.success_result;

exception
    when others then
    raise_application_error(c_stack_info_error, log.error_result(), true);
end mdm_authorize;

-- Заполнение временной таблицы gtt_mdm_sellers (Продавцы)
procedure fill_gtt_mdm_sellers is
    log proc_log_t := proc_log_t.init('fill_gtt_mdm_sellers');
begin

    log.trace('Очистка временной таблицы');

    delete from gtt_mdm_sellers;

    log.trace('Заполние временной таблицы из представлений источника');

    insert into
        gtt_mdm_sellers g
            (
                g.id_sellers,
                g.name_rus,
                g.legal_name_rus,
                g.address_rus,
                g.inn,
                g.id_contractor,
                g.dtm_create,
                g.key_user_create,
                g.dtm_modify,
                g.key_user_modify,
                g.is_deleted
            )
    select
        s.id_sellers,
        s.name_rus,
        s.legal_name_rus,
        s.address_rus,
        s.inn,
        s.id_contractor,
        s.dtm_create,
        s.key_user_create,
        s.dtm_modify,
        s.key_user_modify,
        s.is_deleted
    from
        sm_meta.v_auto_sellers@mskkis.world s -- Продавцы
    ;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_mdm_sellers;

-- Справочник МДМ "Продавцы"
procedure sellers is
    log proc_log_t := proc_log_t.init('sellers');
begin

    log.trace('Заполняем временную таблицу gtt_mdm_sellers_ware');

    fill_gtt_mdm_sellers;

    log.trace('Вычисляем удаленные');

    update
        mdm_sellers t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_mdm_sellers s
            where
                s.id_sellers = t.id_sellers
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_sellers t
    using
    (
        select
            1 status,
            g.id_sellers,
            g.name_rus,
            g.legal_name_rus,
            g.address_rus,
            g.inn,
            g.id_contractor,
            g.dtm_create,
            g.key_user_create,
            g.dtm_modify,
            g.key_user_modify,
            g.is_deleted

        from
            gtt_mdm_sellers g
        minus
        select
            b.status,
            b.id_sellers,
            b.name_rus,
            b.legal_name_rus,
            b.address_rus,
            b.inn,
            b.id_contractor,
            b.dtm_create,
            b.key_user_create,
            b.dtm_modify,
            b.key_user_modify,
            b.is_deleted
        from
            mdm_sellers b
    ) m
    on
    (
        t.id_sellers = m.id_sellers
    )
    when matched then
        update set
            t.change_id       = seq_change_id.nextval,
            t.status          = 1,
            t.ts_update       = current_timestamp,
            t.name_rus        = m.name_rus,
            t.legal_name_rus  = m.legal_name_rus,
            t.address_rus     = m.address_rus,
            t.inn             = m.inn,
            t.id_contractor   = m.id_contractor,
            t.dtm_create      = m.dtm_create,
            t.key_user_create = m.key_user_create,
            t.dtm_modify      = m.dtm_modify,
            t.key_user_modify = m.key_user_modify,
            t.is_deleted      = m.is_deleted
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_sellers,
            t.name_rus,
            t.legal_name_rus,
            t.address_rus,
            t.inn,
            t.id_contractor,
            t.dtm_create,
            t.key_user_create,
            t.dtm_modify,
            t.key_user_modify,
            t.is_deleted
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_sellers,
            m.name_rus,
            m.legal_name_rus,
            m.address_rus,
            m.inn,
            m.id_contractor,
            m.dtm_create,
            m.key_user_create,
            m.dtm_modify,
            m.key_user_modify,
            m.is_deleted
        );

        commit;

        log.success_result();

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end sellers;

-- Заполнение временной таблицы gtt_mdm_sellers_ware (Номенклатура (sellers))
procedure fill_gtt_mdm_sellers_ware is
    log proc_log_t := proc_log_t.init('fill_gtt_mdm_sellers_ware');
begin

    log.trace('Очистка временной таблицы');

    delete from gtt_mdm_sellers_ware;

    log.trace('Заполние временной таблицы из представлений источника');

    insert into
        gtt_mdm_sellers_ware w
            (
                w.id_ware,
                w.id_sellers,
                w.id_contractor,
                w.name,
                w.country,
                w.trade_mark,
                w.ware_group,
                w.merch_model,
                w.gender,
                w.merch_sm,
                w.sellers,
                w.sellers_article,
                w.article,
                w.producer,
                w.size_sm
            )
    select
        t.id_ware        as id_ware,
        s.id_sellers     as id_sellers,
        t.id_contractor  as id_contractor,
        atr_mod.obj_1012 as name,
        c.obj_2_rus      as country,
        tm.obj_2_rus     as trade_mark,
        tg.code_rus      as ware_group,
        mm.obj_2         as merch_model,
        g.code_rus       as gender,
        cm.code          as merch_sm,
        s.name_rus       as sellers,
        t.seller_article as sellers_article,
        t.obj_2          as article,
        t.obj_1068       as producer,
        t.obj_1059       as size_sm
    from
        sm_meta.v_obj_20@mskkis.world t -- Товары
    left join
        sm_meta.v_auto_obj_39@mskkis.world c -- Страны
    on
        c.id_country = t.obj_1138
    left join
        sm_meta.v_auto_obj_69@mskkis.world tm -- Торговые марки
    on
        tm.id_tm = t.obj_1037
    left join
        sm_meta.v_auto_ware_grp@mskkis.world tg -- Товарные группы
    on
        tg.id_ware_grp = t.ware_group
    left join
        sm_meta.v_auto_obj_38@mskkis.world mm -- Мерчендайзинговая модель товара - свойство определенного набора артикулов
    on
        mm.id_mmodel = t.obj_1957
    left join
        sm_meta.v_auto_ware_gender@mskkis.world g -- Пол для товара
    on
        g.id_ware_gender = t.gender
    left join
        sm_meta.v_auto_ware_color_model@mskkis.world cm -- Мерчендайзинговая цветомодель
    on
        cm.id_ware_color_model = t.obj_1958
    left join
        sm_meta.v_auto_sellers@mskkis.world s -- Продавцы
    on
        s.id_sellers = t.id_sellers
    left join
        sm_meta.v_auto_obj_28@mskkis.world  atr_mod -- Атрибуты модели товара
    on
        atr_mod.id_model = t.obj_1056
    where
        t.id_sellers is not null
        and t.id_contractor is not null
    ;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_mdm_sellers_ware;

-- Справочник МДМ "Номенклатура (sellers)"
procedure sellers_ware is
    log proc_log_t := proc_log_t.init('sellers_ware');
begin

    log.trace('Заполняем временную таблицу gtt_mdm_sellers_ware');

    fill_gtt_mdm_sellers_ware;

    log.trace('Вычисляем удаленные');

    update
        mdm_sellers_ware t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_mdm_sellers_ware s
            where
                s.id_ware = t.id_ware
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_sellers_ware t
    using
    (
        select
            1 status,
            g.id_ware,
            g.id_sellers,
            g.id_contractor,
            g.country,
            g.name,
            g.trade_mark,
            g.ware_group,
            g.merch_model,
            g.gender,
            g.merch_sm,
            g.sellers,
            g.sellers_article,
            g.article,
            g.producer,
            g.size_sm
        from
            gtt_mdm_sellers_ware g
        minus
        select
            b.status,
            b.id_ware,
            b.id_sellers,
            b.id_contractor,
            b.country,
            b.name,
            b.trade_mark,
            b.ware_group,
            b.merch_model,
            b.gender,
            b.merch_sm,
            b.sellers,
            b.sellers_article,
            b.article,
            b.producer,
            b.size_sm
        from
            mdm_sellers_ware b
    ) m
    on
    (
        t.id_ware = m.id_ware
    )
    when matched then
        update set
            t.change_id        = seq_change_id.nextval,
            t.status           = 1,
            t.ts_update        = current_timestamp,
            t.id_sellers       = m.id_sellers,
            t.id_contractor    = m.id_contractor,
            t.country          = m.country,
            t.name             = m.name,
            t.trade_mark       = m.trade_mark,
            t.ware_group       = m.ware_group,
            t.merch_model      = m.merch_model,
            t.gender           = m.gender,
            t.merch_sm         = m.merch_sm,
            t.sellers          = m.sellers,
            t.sellers_article  = m.sellers_article,
            t.article          = m.article,
            t.producer         = m.producer,
            t.size_sm          = m.size_sm
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_ware,
            t.id_sellers,
            t.id_contractor,
            t.country,
            t.name,
            t.trade_mark,
            t.ware_group,
            t.merch_model,
            t.gender,
            t.merch_sm,
            t.sellers,
            t.sellers_article,
            t.article,
            t.producer,
            t.size_sm
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_ware,
            m.id_sellers,
            m.id_contractor,
            m.country,
            m.name,
            m.trade_mark,
            m.ware_group,
            m.merch_model,
            m.gender,
            m.merch_sm,
            m.sellers,
            m.sellers_article,
            m.article,
            m.producer,
            m.size_sm
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end sellers_ware;

-- Заполнение временной таблицы gtt_mdm_merch_model (Мерчендайзинговая модель)
procedure fill_gtt_mdm_merch_model is
    log proc_log_t := proc_log_t.init('fill_gtt_mdm_merch_model');
begin

    log.trace('Очистка временной таблицы');

    delete from gtt_mdm_merch_model;

    log.trace('Заполние временной таблицы из представлений источника');

    insert into
        gtt_mdm_merch_model g
            (
                g.id_mmodel ,
                g.name_mmodel
            )
    select
        s.id_mmodel,
        s.obj_2
    from
        sm_meta.v_auto_obj_38@mskkis.world s -- Мерчендайзинговая модель
    ;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_mdm_merch_model;

-- Справочник МДМ "Мерчендайзинговая модель"
procedure merch_model is
    log proc_log_t := proc_log_t.init('merch_model');
begin

    log.trace('Заполняем временную таблицу gtt_mdm_merch_model');

    fill_gtt_mdm_merch_model;

    log.trace('Вычисляем удаленные');

    update
        mdm_merch_model t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_mdm_merch_model s
            where
                s.id_mmodel = t.id_mmodel
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_merch_model t
    using
    (
        select
            1 status,
            g.id_mmodel,
            g.name_mmodel
        from
            gtt_mdm_merch_model g
        minus
        select
            b.status,
            b.id_mmodel,
            b.name_mmodel
        from
            mdm_merch_model b
    ) m
    on
    (
        t.id_mmodel = m.id_mmodel
    )
    when matched then
        update set
            t.change_id   = seq_change_id.nextval,
            t.status      = 1,
            t.ts_update   = current_timestamp,
            t.name_mmodel = m.name_mmodel
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_mmodel,
            t.name_mmodel
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_mmodel,
            m.name_mmodel
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end merch_model;

-- Заполнение временной таблицы gtt_mdm_merch_colorsize (Мерчендайзинговый цветоразмер)
procedure fill_gtt_mdm_merch_colorsize is
    log proc_log_t := proc_log_t.init('fill_gtt_mdm_merch_colorsize');
begin

    log.trace('Очистка временной таблицы');

    delete from gtt_mdm_merch_colorsize;

    log.trace('Заполние временной таблицы из представлений источника');

    insert into
        gtt_mdm_merch_colorsize g
            (
                g.id_merch_colorsize,
                g.name_merch_colorsize
            )
    select
        s.id_merch_colorsize,
        s.code
    from
        sm_meta.v_auto_merch_colorsize@mskkis.world s -- Мерчендайзинговый цветоразмер
    ;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_mdm_merch_colorsize;

-- Справочник МДМ "Мерчендайзинговый цветоразмер"
procedure merch_colorsize is
    log proc_log_t := proc_log_t.init('merch_colorsize');
begin

    log.trace('Заполняем временную таблицу gtt_mdm_merch_model');

    fill_gtt_mdm_merch_colorsize;

    log.trace('Вычисляем удаленные');

    update
        mdm_merch_colorsize t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_mdm_merch_colorsize s
            where
                s.id_merch_colorsize = t.id_merch_colorsize
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_merch_colorsize t
    using
    (
        select
            1 status,
            g.id_merch_colorsize,
            g.name_merch_colorsize
        from
            gtt_mdm_merch_colorsize g
        minus
        select
            b.status,
            b.id_merch_colorsize,
            b.name_merch_colorsize
        from
            mdm_merch_colorsize b
    ) m
    on
    (
        t.id_merch_colorsize = m.id_merch_colorsize
    )
    when matched then
        update set
            t.change_id            = seq_change_id.nextval,
            t.status               = 1,
            t.ts_update            = current_timestamp,
            t.name_merch_colorsize = m.name_merch_colorsize
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_merch_colorsize,
            t.name_merch_colorsize
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_merch_colorsize,
            m.name_merch_colorsize
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end merch_colorsize;

-- Заполнение временной таблицы gtt_mdm_ware_color_model (Мерчендайзинговая  цветомодемодель)
procedure fill_gtt_mdm_ware_color_model is
    log proc_log_t := proc_log_t.init('fill_gtt_mdm_ware_color_model');
begin

    log.trace('Очистка временной таблицы');

    delete from gtt_mdm_ware_color_model;

    log.trace('Заполние временной таблицы из представлений источника');

    insert into
        gtt_mdm_ware_color_model g
            (
                g.id_ware_color_model ,
                g.name_ware_color_model
            )
    select
        s.id_ware_color_model,
        s.code
    from
        sm_meta.v_auto_ware_color_model@mskkis.world s -- Мерчендайзинговая  цветомодемодель
    ;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_mdm_ware_color_model;

-- Справочник МДМ "Мерчендайзинговая  цветомодемодель"
procedure ware_color_model is
    log proc_log_t := proc_log_t.init('ware_color_model');
begin

    log.trace('Заполняем временную таблицу gtt_mdm_ware_color_model');

    fill_gtt_mdm_ware_color_model;

    log.trace('Вычисляем удаленные');

    update
        mdm_ware_color_model t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_mdm_ware_color_model s
            where
                s.id_ware_color_model = t.id_ware_color_model
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_ware_color_model t
    using
    (
        select
            1 status,
            g.id_ware_color_model,
            g.name_ware_color_model
        from
            gtt_mdm_ware_color_model g
        minus
        select
            b.status,
            b.id_ware_color_model,
            b.name_ware_color_model
        from
            mdm_ware_color_model b
    ) m
    on
    (
        t.id_ware_color_model = m.id_ware_color_model
    )
    when matched then
        update set
            t.change_id             = seq_change_id.nextval,
            t.status                = 1,
            t.ts_update             = current_timestamp,
            t.name_ware_color_model = m.name_ware_color_model
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_ware_color_model,
            t.name_ware_color_model
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_ware_color_model,
            m.name_ware_color_model
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end ware_color_model;

-- Заполнение временной таблицы gtt_mdm_ware_gender (Гендерная принадлежность товара)
procedure fill_gtt_mdm_ware_gender is
    log proc_log_t := proc_log_t.init('fill_gtt_mdm_ware_gender');
begin

    log.trace('Очистка временной таблицы');

    delete from gtt_mdm_ware_gender;

    log.trace('Заполние временной таблицы из представлений источника');

    insert into
        gtt_mdm_ware_gender g
            (
                g.id_ware_gender,
                g.code_rus,
                g.moniker_rus
            )
    select
        s.id_ware_gender,
        s.code_rus,
        s.moniker_rus
    from
        sm_meta.v_auto_ware_gender@mskkis.world s -- Гендерная принадлежность товара
    ;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_mdm_ware_gender;

-- Справочник МДМ "Гендерная принадлежность товара"
procedure ware_gender is
    log proc_log_t := proc_log_t.init('ware_gender');
begin

    log.trace('Заполняем временную таблицу');

    fill_gtt_mdm_ware_gender;

    log.trace('Вычисляем удаленные');

    update
        mdm_ware_gender t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_mdm_ware_gender s
            where
                s.id_ware_gender = t.id_ware_gender
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_ware_gender t
    using
    (
        select
            1 status,
            g.id_ware_gender,
            g.code_rus,
            g.moniker_rus
        from
            gtt_mdm_ware_gender g
        minus
        select
            b.status,
            b.id_ware_gender,
            b.code_rus,
            b.moniker_rus
        from
            mdm_ware_gender b
    ) m
    on
    (
        t.id_ware_gender = m.id_ware_gender
    )
    when matched then
        update set
            t.change_id   = seq_change_id.nextval,
            t.status      = 1,
            t.ts_update   = current_timestamp,
            t.code_rus    = m.code_rus,
            t.moniker_rus = m.moniker_rus
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_ware_gender,
            t.code_rus,
            t.moniker_rus
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_ware_gender,
            m.code_rus,
            m.moniker_rus
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end ware_gender;

-- Справочник МДМ "Подразделения"
procedure department is
    log proc_log_t := proc_log_t.init('department');
begin

    log.trace('Вычисляем удаленные');

    update
        mdm_department t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                sm_meta.v_auto_department@mskkis.world s
            where
                s.id_department  = t.id_department
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_department t
    using
    (
        select
            1 status,
            g.id_department,
            g.moniker
        from
            sm_meta.v_auto_department@mskkis.world g
        minus
        select
            b.status,
            b.id_department,
            b.moniker
        from
            mdm_department b
    ) m
    on
    (
        t.id_department = m.id_department
    )
    when matched then
        update set
            t.change_id = seq_change_id.nextval,
            t.status    = 1,
            t.ts_update = current_timestamp,
            t.moniker   = m.moniker
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.id_department,
            t.moniker
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.id_department,
            m.moniker
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end department;

-- Справочник МДМ - Связи нижнего уровня продуктового дерева "RD AP General" (id_node) с номенклатурой id_ware (оно же id_obj_20)
-- берутся только товары селлеров (фильтр по mdm_sellers_ware)
procedure link_ware_tree_prod_rdapgen is
    log proc_log_t := proc_log_t.init('link_ware_tree_prod_rdapgen');
begin

    log.trace('Удаляем не актуальные данные из таблицы');

    delete from
        mdm_link_ware_tree_prod_rdapgen m
    where
        not exists
        (
            select
                1
            from
                mdm_sellers_ware s -- Наполнение "RD AP General"
            where
                s.id_ware = m.id_ware
        );

    log.trace('Вычисление измененных записей');

    merge into
        mdm_link_ware_tree_prod_rdapgen t
    using
    (
        select
            f.id_obj_20 as id_ware,
            f.id_node
        from
            sm_meta.v_auto_node_filling_37@mskkis.world f --линк ware к нодам дерева "RD AP General"
        join
            mdm_sellers_ware o -- обработанный справочник товаров селлеров
        on
            f.id_obj_20 = o.id_ware
        minus
        select
            b.id_ware,
            b.id_node
        from
            mdm_link_ware_tree_prod_rdapgen b
    ) m
    on
    (
        t.id_ware = m.id_ware
    )
    when matched then
        update set
            t.change_id = seq_change_id.nextval,
            t.ts_update = current_timestamp,
            t.id_node   = m.id_node
    when not matched then
        insert
        (
            t.change_id,
            t.ts_update,
            t.id_ware,
            t.id_node
        )
        values
        (
            seq_change_id.nextval,
            current_timestamp,
            m.id_ware,
            m.id_node
        );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end link_ware_tree_prod_rdapgen;

-- Справочник МДМ - Продуктовое дерево "RD AP General", все уровни и узлы. Фильтр по is_deleted и is_active
-- Целевая таблица имеет parent-child структуру
procedure tree_nodes_prod_rdapgen is
    log proc_log_t := proc_log_t.init('tree_nodes_prod_rdapgen');
begin

    log.trace('Удаляем не актуальные данные из таблицы');

    delete from
        mdm_tree_nodes_prod_rdapgen m
    where
        not exists
        (
            select
                1
            from
                sm_meta.v_auto_node_60@mskkis.world s -- Узлы продуктового дерева "RD AP General"
            where
                s.id_node = m.id_node and
                s.is_deleted is null and
                s.is_active = 'Y'
        );

    log.trace('Вычисление измененных записей');

    merge
    into
        mdm_tree_nodes_prod_rdapgen t
    using
        (
            select
                f.id_node,
                f.moniker_rus,
                f.id_parent,
                f.level_num,
                f.node_tree_name,
                f.node_key_tree_name,
                f.sort_num
            from
                sm_meta.v_auto_node_60@mskkis.world f -- Наполнение "RD AP General"
            where
                f.is_deleted is null and
                f.is_active = 'Y'
            minus
            select
                b.id_node,
                b.moniker_rus,
                b.id_parent,
                b.level_num,
                b.node_tree_name,
                b.node_key_tree_name,
                b.sort_num
            from
                mdm_tree_nodes_prod_rdapgen b
        ) m
    on
        (t.id_node = m.id_node)
    when matched then
        update
        set
            t.change_id          = seq_change_id.nextval,
            t.ts_update          = current_timestamp,
            t.moniker_rus        = m.moniker_rus,
            t.id_parent          = m.id_parent,
            t.level_num          = m.level_num,
            t.node_tree_name     = m.node_tree_name,
            t.node_key_tree_name = m.node_key_tree_name,
            t.sort_num           = m.sort_num
    when not matched then
        insert
            (
                t.change_id,
                t.ts_update,
                t.id_node,
                t.moniker_rus,
                t.id_parent,
                t.level_num,
                t.node_tree_name,
                t.node_key_tree_name,
                t.sort_num
            )
        values
            (
                seq_change_id.nextval, /*/ => t.change_id          /*/
                current_timestamp,     /*/ => t.ts_update          /*/
                m.id_node,             /*/ => t.id_node            /*/
                m.moniker_rus,         /*/ => t.moniker_rus        /*/
                m.id_parent,           /*/ => t.id_parent          /*/
                m.level_num,           /*/ => t.level_num          /*/
                m.node_tree_name,      /*/ => t.node_tree_name     /*/
                m.node_key_tree_name,  /*/ => t.node_key_tree_name /*/
                m.sort_num             /*/ => t.sort_num           /*/
            );

        commit;

        log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end tree_nodes_prod_rdapgen;

-- Загрузка справочника (на основании данных МДМ) - Товары продавцов с привязкой к дереву "rd ap general"
procedure ware_prod_rdapgen is
    log proc_log_t := proc_log_t.init('ware_prod_rdapgen');
begin

    log.trace('Удаляем все данные из таблицы');

    delete from
        mdm_ware_prod_rdapgen wpr;

    log.trace('Записываем новые данные');

    insert into
        mdm_ware_prod_rdapgen
            (
                 change_id,
                 ts_update,
                 id_ware,
                 ware,
                 id_category,
                 category,
                 id_subcategory_mfp,
                 subcategory_mfp,
                 id_subcategory_ap,
                 subcategory_ap,
                 id_class,
                 class,
                 id_subclass,
                 subclass
            )
    with tree_node as
        (
            select
                prd.great_child_node,
                prd.id_category,
                rd_cat.moniker_rus as category,
                prd.id_subcategory_mfp,
                rd_subcat_mfp.moniker_rus as subcategory_mfp,
                prd.id_subcategory_ap,
                rd_subcat_ap.moniker_rus as subcategory_ap,
                prd.id_class,
                rd_class.moniker_rus as class,
                prd.id_subclass,
                rd_subclass.moniker_rus as subclass
            from
                (
                    select
                        connect_by_root t.id_node as great_child_node,
                        t.id_node,
                        t.level_num
                    from
                        mdm_tree_nodes_prod_rdapgen t
                    start with t.id_node in
                        (
                            select
                                ts.id_node
                            from
                                mdm_tree_nodes_prod_rdapgen ts
                            join
                                mdm_link_ware_tree_prod_rdapgen lt
                            on
                                lt.id_node = ts.id_node
                                and ts.level_num = 8
                        )
                    connect by prior t.id_parent = t.id_node
                    )
                    pivot
                    (
                        max(id_node)
                        for level_num in
                            (
                                4 as id_category,
                                5 as id_subcategory_mfp,
                                6 as id_subcategory_ap,
                                7 as id_class,
                                8 as id_subclass
                            )
                    ) prd
            left join
                mdm_tree_nodes_prod_rdapgen rd_cat
            on
                rd_cat.id_node = prd.id_category
            left join
                mdm_tree_nodes_prod_rdapgen rd_subcat_mfp
            on
                rd_subcat_mfp.id_node = prd.id_subcategory_mfp
            left join
                mdm_tree_nodes_prod_rdapgen rd_subcat_ap
            on
                rd_subcat_ap.id_node = prd.id_subcategory_ap
            left join
                mdm_tree_nodes_prod_rdapgen rd_class
            on
                rd_class.id_node = prd.id_class
            left join
                mdm_tree_nodes_prod_rdapgen rd_subclass
            on
                rd_subclass.id_node = prd.id_subclass
        )
    select
        seq_change_id.nextval,
        current_timestamp,
        w.id_ware,
        w.name,
        tn.id_category,
        tn.category,
        tn.id_subcategory_mfp,
        tn.subcategory_mfp,
        tn.id_subcategory_ap,
        tn.subcategory_ap,
        tn.id_class,
        tn.class,
        tn.id_subclass,
        tn.subclass
    from
        mdm_sellers_ware w
    join
        mdm_link_ware_tree_prod_rdapgen ltpr
    on
        ltpr.id_ware = w.id_ware
    join
        tree_node tn
    on
        tn.great_child_node = ltpr.id_node
    where
        w.status = 1;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end ware_prod_rdapgen;

-- Загрузка справочников из MDM (для вызова из Job)
procedure inc_mdm is
    log proc_log_t := proc_log_t.init('inc_mdm');
begin

    log.trace('Запуск процедуры загрузки всех сущностей МДМ (для вызова из JOB)');

    -- Авторизация в МДМ
    mdm_authorize;

    -- Справочник МДМ "Продавцы"
    sellers;

    -- Справочник МДМ "Номенклатура (sellers)"
    sellers_ware;

    -- Справочник МДМ "Мерчендайзинговая  цветомодемодель"
    ware_color_model;

    -- Справочник МДМ "Мерчендайзинговый цветоразмер"
    merch_colorsize;

    -- Справочник МДМ "Мерчендайзинговая модель"
    merch_model;

    -- Справочник МДМ "Гендерная принадлежность товара"
    ware_gender;

    -- Справочник МДМ "Подразделения"
    department;

    -- Справочник МДМ - Связи продуктового дерева "RD AP General" с номенклатурой
    link_ware_tree_prod_rdapgen;

    -- Справочник МДМ - Узлы продуктового дерева "RD AP General"
    tree_nodes_prod_rdapgen;

    -- Справочник (на основании данных МДМ) - Товары продавцов с привязкой к дереву "rd ap general"
    ware_prod_rdapgen;

    log.success_result;

end inc_mdm;

end staging_mdm;

/

