create package staging_mdm is

--  Авторизация в MDM
procedure mdm_authorize;

-- Справочник МДМ "Продавцы"
procedure sellers;

-- Справочник МДМ "Номенклатура (sellers)"
procedure sellers_ware;

-- Справочник МДМ "Мерчендайзинговая модель"
procedure merch_model;

-- Справочник МДМ "Мерчендайзинговый цветоразмер"
procedure merch_colorsize;

-- Справочник МДМ "Мерчендайзинговая  цветомодемодель"
procedure ware_color_model;

-- Справочник МДМ "Гендерная принадлежность товара"
procedure ware_gender;

-- Справочник МДМ "Подразделения"
procedure department;

-- Справочник МДМ - Связи продуктового дерева "RD AP General" с номенклатурой
procedure link_ware_tree_prod_rdapgen;

-- Справочник МДМ - Узлы продуктового дерева "RD AP General"
procedure tree_nodes_prod_rdapgen;

-- Справочник (на основании данных МДМ) - Товары продавцов с привязкой к дереву "rd ap general"
procedure ware_prod_rdapgen;

-- Загрузка справочников из MDM (для вызова из Job)
procedure inc_mdm;

end staging_mdm;

/

