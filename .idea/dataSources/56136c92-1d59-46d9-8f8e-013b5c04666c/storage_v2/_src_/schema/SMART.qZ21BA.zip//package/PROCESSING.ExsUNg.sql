create package processing is

-- Расчет остатков товаров мерчантов на дату
procedure calculate_merchant_stock_on_date(p_date_stock date);

-- Расчет остатков товаров мерчантов
procedure calculate_merchant_stocks;

-- Расчет данных по продажам и возвратам на дату
procedure calculate_merchant_sales_returns_on_date(p_date_sales_returns date);

-- Расчет данных по продажам и возвратам
procedure calculate_merchant_sales_returns;  

end processing;
/

