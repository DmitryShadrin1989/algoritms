create package body service_dev is

c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Заполнение временной таблицы gtt_mdm_sellers (Продавцы)
procedure copy_data_from_prod is
    log proc_log_t := proc_log_t.init('copy_data_from_prod');
    c_db_env constant varchar2(30) := sys_context('userenv', 'DB_NAME');  
begin
    
    log.trace('Проверяем БД. Если процедура запускается с прода вызываем исключение');
    
    if c_db_env = 'SMART_PROD' then
        raise_application_error(c_stack_info_error, log.error_result(), true); 
    end if;
  
    log.trace('Копируем данные с smart.prod');
    
    manage_dyn_loading.loading_group_table_data(p_group_name => 'data_from_prod');
    
    log.trace('Загружаем данные из МДМ');
    
    staging_mdm.inc_mdm;
    
    log.trace('Загружаем данные из ИПРа');
    staging_isp.start_load;
    staging_isp.full_download_calendar_mfp_sm;
    staging_isp.end_load;
    
    log.trace('Выполняем процедуры процессинга'); 
    
    processing.calculate_merchant_stocks;
    processing.calculate_merchant_sales_returns;
    
    log.trace('Выполняем процедуры финальной подготовки данных');
    
    prepare_final.calculate_final_sales_ware_by_day;
    
    prepare_final.calculate_final_turnover_by_day;
    
    log.success_result;
    
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);
            
end copy_data_from_prod;

  
end service_dev;
/

