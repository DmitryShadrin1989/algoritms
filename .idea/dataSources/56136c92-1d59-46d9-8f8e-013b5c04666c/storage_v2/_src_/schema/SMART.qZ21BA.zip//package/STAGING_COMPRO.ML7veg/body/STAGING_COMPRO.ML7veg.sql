create package body staging_compro is

    c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Заполнение временной таблицы gtt_compro_goods_sale (Staging данных по продажам ComPro)
procedure fill_gtt_compro_goods_sale is
    log proc_log_t := proc_log_t.init('fill_gtt_compro_goods_sale');  
begin
  
    log.trace('Очистка временной таблицы');
  
    delete from gtt_compro_goods_sale;
    
    log.trace('Заполние временной таблицы из таблиц-реплик');

    insert into
        gtt_compro_goods_sale g
            (
                g.order_code,
                g.line_code,
                g.shop_num,
                g.release_ts,
                g.id_sellers,
                g.id_ware,
                g.quantity,
                g.price,
                g.discont_summa
            )
    with orders as -- таблица со строками заказов на стадии выдачи, только по неменклатуре продавцов
        (
            select
                r.order_code,
                l.code as line_code,
                r.release_ts,
                w.id_sellers,
                l.id_ware,
                l.qty_ordered as quantity,
                l.price        
            from 
                com_order_release r -- Выдачи
            join
                com_order_line l -- Строки версии заказа
            on 
                l.version_code = r.order_version_code
            join
                mdm_sellers_ware w -- Номенклатура продавцов
            on
                w.id_ware = l.id_ware
        )
      , discont as --группируем все скидки по строке заказа
          (   
              select  
                  d.order_line_code,    
                  sum(d.summa) as discont_summa  
              from 
                  com_order_line_discount d
              where 
                  d.order_line_code in (
                                           select 
                                               o.line_code
                                           from 
                                               orders o 
                                       )  
              group by 
                  d.order_line_code  
          )
      select
          o.order_code,
          o.line_code,
          p.shop_num,
          o.release_ts,
          o.id_sellers,
          o.id_ware,
          o.quantity,
          o.price,
          d.discont_summa    
      from 
          orders o 
      left join 
          discont d
      on 
          d.order_line_code = o.line_code
      left join
          com_order_pickup p -- Атрибуты заказа самовывоза
      on  
          p.order_code = o.order_code
    ;
    
    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end fill_gtt_compro_goods_sale;

-- Staging данных по продажам ComPro
procedure goods_sale is
    log proc_log_t := proc_log_t.init('goods_sale');  
begin
  
    log.trace('Заполняем временную таблицу gtt_compro_goods_sale');
  
    fill_gtt_compro_goods_sale;
    
    log.trace('Вычисляем удаленные');
    
    update
        compro_goods_sale t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_compro_goods_sale s
            where
                s.order_code = t.order_code
                and s.line_code = t.line_code
        );
    
    log.trace('Вычисление измененных записей');    
    
    merge into
        compro_goods_sale t
    using
    (
        select
            1 status,
            g.order_code,
            g.line_code,
            g.shop_num,
            g.release_ts,
            g.id_sellers,
            g.id_ware,
            g.quantity,
            g.price,
            g.discont_summa
        from
            gtt_compro_goods_sale g
        minus
        select
            b.status,
            b.order_code,
            b.line_code,
            b.shop_num,
            b.release_ts,
            b.id_sellers,
            b.id_ware,
            b.quantity,
            b.price,
            b.discont_summa               
        from
            compro_goods_sale b
    ) m
    on
    (
        t.order_code = m.order_code
        and t.line_code = m.line_code
    )
    when matched then
        update set
            t.change_id     = seq_change_id.nextval,
            t.status        = 1,
            t.ts_update     = current_timestamp,
            t.shop_num      = m.shop_num,
            t.release_ts    = m.release_ts,
            t.id_sellers    = m.id_sellers,
            t.id_ware       = m.id_ware,
            t.quantity      = m.quantity,
            t.price         = m.price,
            t.discont_summa = m.discont_summa                
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.order_code,
            t.line_code,
            t.shop_num,
            t.release_ts,
            t.id_sellers,
            t.id_ware,
            t.quantity,
            t.price,
            t.discont_summa               
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.order_code,
            m.line_code,
            m.shop_num,
            m.release_ts,
            m.id_sellers,
            m.id_ware,
            m.quantity,
            m.price,
            m.discont_summa                
        );
        
        commit;
        
        log.success_result;
        
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);
        
end goods_sale;

-- Заполнение временной таблицы для Staging данных по возвратам ComPro
procedure fill_gtt_compro_goods_returns is
    log proc_log_t := proc_log_t.init('fill_gtt_compro_goods_returns');  
begin
  
    log.trace('Очистка временной таблицы');
  
    delete from gtt_compro_goods_returns;
    
    log.trace('Заполние временной таблицы из таблиц-реплик ');

    insert into
        gtt_compro_goods_returns g
            (
                g.return_code,
                g.line_return_code,
                g.order_code,
                g.id_sellers,
                g.id_ware,
                g.basket_date,
                g.quantity,
                g.price,
                g.refund_amount,
                g.shop_num
            )
        select
            r.code          as return_code,      
            rw.code         as line_return_code, 
            r.order_code,                        
            w.id_sellers, 
            rw.id_ware, 
            rb.basket_date, 
            rw.qty          as quantity, 
            rw.price, 
            rw.qty*rw.price as refund_amount, 
            oc.source_id    as shop_num 
        from
            com_order_return r -- возвраты
        join 
            com_order_basket rb -- корзина возврата
        on 
            rb.code = r.basket_code
        join 
            com_order_return_ware rw -- спецификации возвратов
        on 
            rw.return_code = r.code
        join 
            com_order_communication oc -- коммуникации по заказам
        on 
            oc.code = r.comm_code 
            and oc.source_type_code = 10 -- условие на магазин
        join 
            mdm_sellers_ware w -- номенклатура селлеров
        on 
            w.id_ware = rw.id_ware;
            
        log.success_result;
  
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);
        
end fill_gtt_compro_goods_returns;

-- Staging данных по возвратам ComPro
procedure goods_returns is
    log proc_log_t := proc_log_t.init('goods_returns');
begin
  
    log.trace('Заполняем временную таблицу');
  
    fill_gtt_compro_goods_returns;
    
    log.trace('Вычисляем удаленные');
    
    update
        compro_goods_returns t
    set
        t.change_id = seq_change_id.nextval,
        t.status    = 0,
        t.ts_update = current_timestamp
    where
        t.status = 1
        and not exists
        (
            select
                1
            from
                gtt_compro_goods_returns s
            where
                s.return_code = t.return_code
                and s.line_return_code = t.line_return_code
        );
    
    log.trace('Вычисление измененных записей');    
     
    merge into
        compro_goods_returns t
    using
    (
        select
            1 status,
            g.return_code,
            g.line_return_code,
            g.order_code,
            g.id_sellers,
            g.id_ware,
            g.basket_date,
            g.quantity,
            g.price,
            g.refund_amount,
            g.shop_num
        from
            gtt_compro_goods_returns g
        minus
        select
            b.status,
            b.return_code,
            b.line_return_code,
            b.order_code,
            b.id_sellers,
            b.id_ware,
            b.basket_date,
            b.quantity,
            b.price,
            b.refund_amount,
            b.shop_num             
        from
            compro_goods_returns b
    ) m
    on
    (
        t.return_code = m.return_code
        and t.line_return_code = m.line_return_code
    )
    when matched then
        update set
            t.change_id     = seq_change_id.nextval,
            t.status        = 1,
            t.ts_update     = current_timestamp,
            t.order_code    = m.order_code,
            t.id_sellers    = m.id_sellers,
            t.id_ware       = m.id_ware,
            t.basket_date   = m.basket_date,
            t.quantity      = m.quantity,
            t.price         = m.price,
            t.refund_amount = m.refund_amount,
            t.shop_num      = m.shop_num
    when not matched then
        insert
        (
            t.change_id,
            t.status,
            t.ts_update,
            t.return_code,
            t.line_return_code,
            t.order_code,
            t.id_sellers,
            t.id_ware,
            t.basket_date,
            t.quantity,
            t.price,
            t.refund_amount,
            t.shop_num                
        )
        values
        (
            seq_change_id.nextval,
            1,
            current_timestamp,
            m.return_code,
            m.line_return_code,
            m.order_code,
            m.id_sellers,
            m.id_ware,
            m.basket_date,
            m.quantity,
            m.price,
            m.refund_amount,
            m.shop_num                 
        );
        
        commit;
        
        log.success_result;
        
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);
        
end goods_returns;

-- Staging данных ComPro (для вызова из Job)
procedure inc_compro is
    log proc_log_t := proc_log_t.init('inc_compro');
begin
  
    log.trace('Staging данных ComPro (общая процедура для вызова из Job)');
  
    -- Staging данных по продажам ComPro
    goods_sale;
    
    -- Staging данных по возвратам ComPro
    goods_returns;
    
    log.success_result;

end inc_compro;

end staging_compro;
/

