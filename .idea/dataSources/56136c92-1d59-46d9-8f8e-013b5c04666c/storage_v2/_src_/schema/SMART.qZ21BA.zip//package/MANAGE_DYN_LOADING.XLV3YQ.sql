create package manage_dyn_loading is

-- Загрузка данных по настройке
procedure loading_table_data(p_id_table number); 

-- Загрузка данных по группе настроек
procedure loading_group_table_data(p_group_name varchar2); 

end manage_dyn_loading;
/

