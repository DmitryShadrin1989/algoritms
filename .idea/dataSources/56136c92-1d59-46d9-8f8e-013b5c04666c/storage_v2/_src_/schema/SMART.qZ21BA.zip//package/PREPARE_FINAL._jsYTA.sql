create package prepare_final is

-- Расчет финальных данных для backend по продажам
procedure calculate_final_sales_ware_by_day;

-- Расчет финальных данных для backend по оборотам продаж
procedure calculate_final_turnover_by_day(p_day date default trunc(sysdate) - numtodsinterval(1, 'day'));

-- Расчет оборачиваемости
function get_turnover
    (
        p_stock_u number,
        p_week_3 number,
        p_week_2 number,
        p_last_week number,
        p_this_week number,
        p_number_day_in_week number
    )
return number;

-- Расчет рекомендованного заказа
function get_recommended_order
    (
        p_stock_u number,
        p_week_3 number,
        p_week_2 number,
        p_last_week number,
        p_this_week number,
        p_delivery_u number
    )
return number;

-- Расчет финальных данных для backend брендам
procedure calculate_final_brand_by_day;

end prepare_final;

/

