create package staging_compro is

-- Staging данных по продажам ComPro
procedure goods_sale;

-- Staging данных по возвратам ComPro
procedure goods_returns;

-- Staging данных ComPro (для вызова из Job)
procedure inc_compro;

end staging_compro;
/

