create package body staging_mks is

    c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Запрос расчета данных
procedure start_calc_data
(
    p_data_name varchar2
) as
    log proc_log_t := proc_log_t.init(p_proc_name => 'start_calc_data', p_proc_param => 'p_data_name =>' || p_data_name);

    l_data_type        varchar2(100 char);
    l_name_procedure   varchar2(100 char);
    l_id_request       number;
    l_data_requests pk_data.data_requests@mksdb.world := pk_data.data_requests@mksdb.world;    
begin
  
    log.trace('Получаем из настроек имя процедуры источника с помощью которой получим тип данных для запуска расчета остатков');
    
    l_name_procedure :=
        adm_p_settings.get_str
            (
                p_param => p_data_name
            );
            
    log.trace('');
    
    -- Получаем тип данных для запуска расчета остатков
    execute immediate 
        'select pk_data.'||l_name_procedure||'@mksdb.world from dual' 
            into l_data_type;
    
    log.trace('');
    
    -- Подготовливаем параметры для передачи в процедуру запуска расчета остатков   
    l_data_requests :=
        pk_data.data_requests@mksdb.world
        (
            pk_data.data_request@mksdb.world
            (
                l_data_type,
                adm_p_settings.get_str -- Получаем из настроек номер версии для данного типа данных
                    (
                        p_param => p_data_name||'_version'
                    )
            )
        );
    
    log.trace('');
        
    -- Запускаем расчет остатков
    l_id_request :=
        pk_data.start_calc@mksdb.world
        (
            a_consumer      => 'SMART',
            a_data_requests => l_data_requests
        );
    
    log.trace('');
        
    -- Сохраняем номер запроса в нашей таблице 
    insert into mks_request
        (
         id_request, 
         datetime_request,
         data_type,
         state 
        )
    values
        (
         l_id_request, 
         current_date,
         p_data_name,
         'NEW'
        );
    
    commit;
    
    log.success_result;
  
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end start_calc_data;

-- Подтверждение запроса
procedure confirm_request
(
    p_id_request number  -- Идентификатор запроса    
) as
    log proc_log_t := proc_log_t.init(p_proc_name => 'confirm_request', p_proc_param => 'p_id_request =>' || p_id_request);
begin
  
    log.trace('Attempt to confirm the loading of the remaining goods of merchants');
  
    pk_data.mark_as_read@mksdb.world
        (
            a_request_id => p_id_request
        );
        
    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end confirm_request;

-- Загрузка состояний запросов в МКС
procedure update_requests_states as
    log proc_log_t := proc_log_t.init('update_requests_states');  
begin
  
    log.trace('Update the status of the request');
  
    for r in
        (
            select 
                m.id_request,
                m.state,
                m.datetime,
                m.message,
                m.data_actual_date     
            from 
                v_request_state@mksdb.world m
            join 
                mks_request s
            on
                s.id_request = m.id_request
                and s.state in ('NEW', 'EXECUTING', 'EXECUTED')
        )
    loop
        update
            mks_request
        set
            state = r.state, 
            datetime_state = r.datetime,
            message = r.message,
            data_actual_date = r.data_actual_date    
        where
            id_request = r.id_request;
    end loop;
        
    commit;
    
    log.success_result;
    
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end update_requests_states;

-- Загрузка данных МКС по остаткам товаром мерчантов (merchants/sellers)
procedure loading_merchant_stock_data as
    log proc_log_t := proc_log_t.init('loading_merchant_stock_data');
begin
  
    log.trace('Обновляем состоянение запросов ');
  
    update_requests_states;
    
    log.trace('Запускаем цикл по выполненным запросам');
  
    for l in
        (
            select 
                r.id_request,
                r.data_actual_date,
                (
                    select
                        max(m.balance_date) -- дата в нашей таблице остатков
                    from
                        mks_merchant_stock_data m
                    where 
                        trunc(m.balance_date) = trunc(r.data_actual_date)
                ) as balance_date
            from 
                mks_request r            
            where
                r.data_type = 'mks_merchant_stock_data'
                and r.state = 'EXECUTED'
                and r.datetime_upload is null -- Признак, что данные по этому запросу уже загружены
            order by
                r.data_actual_date desc -- Сортируем от запросов с самыми "свежими" данными к более старым            
        )
    loop
        
        -- Если в таблице остатков не было записей на дату, или дата старше той, что в запросе, обновим данные
        if l.balance_date is null or l.data_actual_date > l.balance_date then
            
            log.trace('Удаляем данные из таблицы остатков на дату - ' || trunc(l.data_actual_date));
            
            delete from 
                mks_merchant_stock_data m
            where
                trunc(m.balance_date) = trunc(l.data_actual_date);
            
            log.trace('Добавляем новые записи по остаткам, по запросу - ' || l.id_request);
            
            insert into 
                mks_merchant_stock_data smart 
                    (
                    smart.change_id,
                    smart.ts_update,
                    smart.id_request,
                    smart.balance_date,
                    smart.id_ware,
                    smart.id_department,
                    smart.id_department_sourse,
                    smart.stock_type,
                    smart.quantity,
                    smart.id_sellers,
                    smart.id_ware_type,
                    smart.id_ware_condition
                    )
            select
                seq_change_id.nextval,
                current_timestamp,
                l.id_request,
                l.data_actual_date,
                mks.id_ware,
                mks.id_department,
                mks.id_department_source,
                mks.stock_type,
                mks.quantity,
                mks.id_sellers,
                mks.id_ware_type,
                mks.id_ware_condition        
            from 
                sm_mks_data.v_merchant_stock_data@mksdb.world mks
            where 
                mks.id_request = l.id_request;
            
            log.trace('Заполняем поле "Дата и время загрузки в SMART", по запросу - ' || l.id_request);
            
            update
                mks_request req
            set
                req.datetime_upload = current_timestamp
            where
                req.id_request = l.id_request;
                            
            commit;      
             
        end if;    
        
        log.trace('Подтверждение загрузки, по запросу - ' || l.id_request);
        
        confirm_request
            (
                p_id_request => l.id_request
            );    

    end loop;
    
    log.success_result;
    
exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);
        
end loading_merchant_stock_data;

end staging_mks;
/

