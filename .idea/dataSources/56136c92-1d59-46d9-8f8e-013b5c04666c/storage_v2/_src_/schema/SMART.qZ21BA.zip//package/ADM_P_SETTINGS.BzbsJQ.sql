create package adm_p_settings is

    -- Чтение параметра типа number
    function get_num (p_param varchar2) return number;

    -- Чтение параметра типа varchar2
    function get_str (p_param varchar2) return varchar2;

    -- Чтение параметра типа date
    function get_date (p_param varchar2) return date;

end adm_p_settings;

/

