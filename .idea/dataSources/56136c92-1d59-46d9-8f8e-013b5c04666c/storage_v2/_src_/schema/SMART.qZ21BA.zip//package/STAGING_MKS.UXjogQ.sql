create package staging_mks is

-- Запрос расчета данных
procedure start_calc_data(p_data_name varchar2);

-- Подтверждение запроса
procedure confirm_request(p_id_request number);

-- Загрузка состояний запросов в МКС
procedure update_requests_states;

-- Загрузка данных МКС по остаткам товаром мерчантов (merchants/sellers)
procedure loading_merchant_stock_data;

end staging_mks;
/

