create type body proc_log_t is
  
-- Создает логер для процедуры
constructor function proc_log_t(
    p_proc_name varchar2            -- Имя процедуры
)
return self as result
is
begin
  proc_name := substr( p_proc_name, 1, 200);            -- исключаем ошибку из-за переполнения строки
  return;
end proc_log_t;

-- Начинает логирование процедуры
member procedure init(
    p_proc_param varchar2 := null,  -- Параметры процедуры
    p_req clob := null,             -- Текст запроса с параметрами процедуры
    p_text varchar2 := null         -- Сообщение о начале выполнения процедуры (по умолчанию формируется автоматически)
)
is
begin
    -- используем substr для исключения ошибки из-за переполнения строки
    if p_proc_param is not null then
        proc_param := substr( p_proc_param, 1, 4000);
    end if;
    manage_logs.proc_log_start(
        p_proc_name     => proc_name,
        p_proc_param    =>
            case when p_req is not null then
                case when length( p_req) > 4000 then
                    substr( p_req, 1, 3900) || '... (length=' || length( p_req) || ')'
                else
                    p_req
                end
            else
                -- по возможности передаем необрезанное значение из p_proc_param (может быть выведено через dbms_output)
                coalesce( p_proc_param, proc_param)
            end,
        p_value         => p_text
    );
end init;

-- Начинает логирование и возвращает логер для процедуры
static function init(
    p_proc_name varchar2,           -- Имя процедуры
    p_proc_param varchar2 := null,  -- Параметры процедуры
    p_req clob := null,             -- Текст запроса с параметрами процедуры
    p_text varchar2 := null         -- Сообщение о начале выполнения процедуры (по умолчанию формируется автоматически)
)
return proc_log_t
is

    log proc_log_t;

begin
    log := proc_log_t(
        p_proc_name => p_proc_name
    );
    log.init(
        p_proc_param    => p_proc_param,
        p_req           => p_req,
        p_text          => p_text
    );
    return log;
end init;

-- Устанавливает параметры процедуры для записи в лог
member procedure set_proc_param(
    p_proc_param varchar2           -- Параметры процедуры
)
is
begin
    proc_param := p_proc_param;
    trace( 'set_proc_param: ' || p_proc_param);
end set_proc_param;

-- Логирует предупреждающее сообщение
member procedure warn(
    self in proc_log_t,         -- Технический параметр (явно задаем модификатор IN для self-указателя метода)
    p_text varchar2                 -- Текст сообщения
)
is
begin
    manage_logs.proc_log_value(
        p_value => p_text
    );
end warn;

-- Логирует информационное сообщение
member procedure info(
    self in proc_log_t,         -- Технический параметр (явно задаем модификатор IN для self-указателя метода)
    p_text varchar2                 -- Текст сообщения
)
is
begin
    manage_logs.proc_log_value(
        p_value => p_text
    );
end info;

-- Логирует отладочное сообщение
member procedure debug(
    self in proc_log_t,         -- Технический параметр (явно задаем модификатор IN для self-указателя метода)
    p_text varchar2                 -- Текст сообщения
)
is
begin
    manage_logs.proc_log_value(
        p_value => p_text
    );
end debug;

-- Логирует трассировочное сообщение
member procedure trace(
    self in proc_log_t,         -- Технический параметр (явно задаем модификатор IN для self-указателя метода)
    p_text varchar2                 -- Текст сообщения
)
is
begin
    manage_logs.proc_log_value(
        p_value => p_text
    );
end trace;

-- Логирует успешное завершение процедуры
member procedure success_result(
    p_res varchar2 := null,         -- Результат успешного выполнения
    p_text varchar2 := null         -- Сообщение о завершении процедуры (по умолчанию формируется автоматически)
)
is

    c_ok_code constant pls_integer := 200;  -- Код успешного выполнения
    v_final_log_mock varchar2(4000);        -- Заглушка для получения лога. Не используется
begin
    manage_logs.proc_log_end(
        o_high_level_log_error  => v_final_log_mock,
        p_proc_name             => proc_name,
        p_proc_param            => proc_param,
        p_value                 => p_text,
        p_error_code            => c_ok_code,
        p_error_text            => p_res
    );
end success_result;

-- Логирует успешное завершение процедуры и возвращает стандартный код и сообщение об успешном выполнении
member procedure set_success_result(
    o_code out integer,             -- Стандартный код успешного выполнения (возврат)
    o_res out varchar2,             -- Стандартное сообщение об успешном выполнении (возврат)
    p_text varchar2 := null         -- Сообщение о завершении процедуры (по умолчанию формируется автоматически)
)
is

    c_ok_text constant varchar2(4) := 'ok';         -- Результат при успешном выполнении
    c_ok_code constant pls_integer := 200;          -- Код успешного выполнения

begin
    o_code := c_ok_code;
    o_res := c_ok_text;
    success_result(
        p_res   => o_res,
        p_text  => p_text
    );
end set_success_result;

-- Формирует сообщение об ошибке, логирует завершение процедуры с ошибкой и возвращает сообщение об ошибке
-- (вызывается из блока обработки исключений процедуры)
member function error_result(
    p_error_text varchar2 := null,  -- Текст сообщения об ошибке (по умолчанию формируется автоматически)
    p_proc_param varchar2 := null,  -- Параметры процедуры
    p_req clob := null,             -- Текст запроса с параметрами процедуры
    p_text varchar2 := null        -- Сообщение о завершении процедуры (по умолчанию формируется автоматически)
)
return varchar2
is

    c_db_error constant pls_integer := 500;         -- Код выполнения с ошибкой

    v_error_text varchar2(4000);                    -- Текст сформированного сообщения об ошибке
    v_final_log varchar2(4000);
    v_top_level_flag boolean := manage_logs.proc_log_is_top(proc_name);-- Ошибка в процедуре верхнего уровня?

    -- Формирует текст сообщения об ошибке
    procedure make_error_text(
       p_proc_param varchar2
    )
    is
    begin
        v_error_text := substr( -- исключаем ошибку из-за переполнения строки
            case when not v_top_level_flag then
                'Error on ' || proc_name
            end
                || replace( -- удаляет пробел и скобки если нет никаких параметров
                    ' (' || substr( -- убирает лишнюю ведущую запятую
                            case when p_proc_param is not null then ', ' || p_proc_param end,
                            2)
                        || ')',
                        ' ()', ''
                    )
            || case when v_top_level_flag then
                    ':' || chr(10) || dbms_utility.format_error_stack
                    || 'Error_backtrace: ' || dbms_utility.format_error_backtrace
                else
                    '.'
                end,
            1, 4000
        );
    end make_error_text;

begin
    if p_error_text is null then
        make_error_text(
           p_proc_param    => coalesce( p_proc_param, proc_param)
        );
    end if;
    manage_logs.proc_log_end(
        o_high_level_log_error  => v_final_log,
        p_proc_name             => proc_name,
        p_proc_param            =>
            case when p_req is not null then
                case when length( p_req) > 4000 then
                    substr( p_req, 1, 3900) || '... (length=' || length( p_req) || ')'
                else
                    p_req
                end
            else
                coalesce( p_proc_param, proc_param)
            end,
        p_value             => p_text,
        p_error_code        => c_db_error,
        p_error_text        => coalesce( p_error_text, v_error_text)
    );
    v_final_log := case v_top_level_flag when true then v_final_log else v_error_text end;
    return coalesce(p_error_text, v_final_log);
end error_result;

-- Формирует сообщение об ошибке, логирует завершение процедуры с ошибкой и возвращает код и сообщение об ошибке
-- (вызывается из блока обработки исключений процедуры)
member procedure set_error_result(
    self in proc_log_t,         -- Технический параметр (явно задаем модификатор IN для self-указателя метода)
    o_code out integer,             -- Стандартный код выполнения с ошибкой (возврат)
    o_res out varchar2,             -- Сообщение об ошибке (возврат)
    p_error_text varchar2 := null,  -- Текст сообщения об ошибке (по умолчанию формируется автоматически)
    p_proc_param varchar2 := null,  -- Параметры процедуры
    p_req clob := null,             -- Текст запроса с параметрами процедуры
    p_text varchar2 := null         -- Сообщение о завершении процедуры (по умолчанию формируется автоматически)
)
is

    c_db_error constant pls_integer := 500;         -- Код выполнения с ошибкой

begin
    o_code := c_db_error;
    o_res := error_result(
        p_error_text        => p_error_text,
        p_proc_param        => p_proc_param,
        p_req               => p_req,
        p_text              => p_text
    );
end set_error_result;
  
end;
/

