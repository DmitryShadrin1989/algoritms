create package manage_logs is

-- Устанавливает признак вывода сообщений лога через dbms_output
procedure set_log_dbms_output_flag(
    p_log_dbms_output_flag boolean := null      -- Признак вывода сообщений лога через dbms_output (по умолчанию нет)
);

-- Возвращает признак вывода сообщений лога через dbms_output (true если да, false если нет)
function get_log_dbms_output_flag
return boolean;

-- Начало протоколирования выполнения процедуры
procedure proc_log_start(
    p_proc_name varchar2 := null,   -- Имя пакета.процедуры.переменной
    p_proc_param varchar2 := null,  -- Параметры процедуры
    p_value varchar2 := null        -- Возможная первая запись о начале выполнения
);
  
-- Добавление записи в лог выполнения процедуры
procedure proc_log_value(
    p_value varchar2 := null        -- Значение для протоколирования
);

-- Завершение выполнения процедуры
procedure proc_log_end(
    o_high_level_log_error out varchar2,    -- Лог формируемый для процедуры верхнего уровня
    p_proc_name varchar2 := null,           -- Имя пакета.процедуры.переменной
    p_proc_param varchar2 := null,          -- Параметры процедуры
    p_value varchar2 := null,               -- Возможная первая запись о начале выполнения
    p_error_code number := null,            -- Код ошибки
    p_error_text varchar2 := null           -- Текст ошибки
);

-- Функция возвращает true если имя процедуры = той, в которой лог открыт, т.е. верхнеуровневой
function proc_log_is_top(p_proc_name in varchar2) return boolean;

end ;
/

