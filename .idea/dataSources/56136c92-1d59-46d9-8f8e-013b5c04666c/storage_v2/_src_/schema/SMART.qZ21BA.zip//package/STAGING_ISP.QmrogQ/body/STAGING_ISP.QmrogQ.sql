create package body staging_isp is

    c_stack_info_error constant pls_integer := -20100; -- Дополнительная информация по ошибке

-- Начало загрузки/выгрузки данных из/в ИПР
procedure start_load is
    log proc_log_t := proc_log_t.init('start_load');
begin

    log.trace('Начало загрузки из ИПРа');

    isp.isp_unload.start_load@isp.world
        (
             p_recipient_name => adm_p_settings.get_str('isp_recipient_name'), -- имя потребителя
             p_entity_name    => adm_p_settings.get_str('isp_entity_name'), -- имя потока
             p_type_unload    => adm_p_settings.get_str('isp_type_unload') -- тип выгрузки: 1 - полная, 2 - Инкрементальная
        );

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end start_load;

-- Конец загрузки/выгрузки данных из/в ИПР
procedure end_load is
    log proc_log_t := proc_log_t.init('end_load');
    v_dblinc varchar2(50 char) := 'isp.world';
begin

    log.trace('Окончание загрузки из ИПРа');



    isp.isp_unload.end_load@isp.world
        (
             p_status_unload => 0 -- закончили без ошибок, 1 - с ошибкой
        );

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end end_load;

-- Полная загрузка Календарной иерархии SM MFP(из Календарного модуля BC)
procedure full_download_calendar_mfp_sm is
    log proc_log_t := proc_log_t.init('full_download_calendar_mfp_sm');
begin

    log.trace('Очищаем таблицу перед загрузкой');

    delete from isp_calendar_mfp_sm;

    log.trace('Загружаем календарную иерархию');

    insert into
        isp_calendar_mfp_sm
            (
                change_id,
                ts_update,
                isp_code,
                day_code,
                day_label,
                month_code,
                month_label,
                month_year_code,
                month_year_label,
                year_code,
                year_label,
                season_code,
                season_label,
                week_code,
                week_label,
                week_aw_code,
                week_aw_label,
                week_ss_code,
                week_ss_label,
                day_year_code,
                day_year_label,
                week_year_code,
                week_year_label,
                day_week_code,
                day_week_label,
                woy_month_code,
                woy_month_label,
                fiscal_month_year_code,
                fiscal_month_year_label,
                fiscal_year_code,
                fiscal_year_label,
                fiscal_month_code,
                fiscal_month_label,
                fiscal_season_code,
                fiscal_season_label,
                calendar_code
            )
    select
        seq_change_id.nextval,
        current_timestamp,
        c.isp_code,
        c.day_code,
        c.day_label,
        c.month_code,
        c.month_label,
        c.month_year_code,
        c.month_year_label,
        c.year_code,
        c.year_label,
        c.season_code,
        c.season_label,
        c.week_code,
        c.week_label,
        c.week_aw_code,
        c.week_aw_label,
        c.week_ss_code,
        c.week_ss_label,
        c.day_year_code,
        c.day_year_label,
        c.week_year_code,
        c.week_year_label,
        c.day_week_code,
        c.day_week_label,
        c.woy_month_code,
        c.woy_month_label,
        c.fiscal_month_year_code,
        c.fiscal_month_year_label,
        c.fiscal_year_code,
        c.fiscal_year_label,
        c.fiscal_month_code,
        c.fiscal_month_label,
        c.fiscal_season_code,
        c.fiscal_season_label,
        c.calendar_code
    from
        isp.v_swc_bc_calendar_mfp_sm@isp.world c;

    commit;

    log.success_result;

exception
    when others then
        rollback;
        raise_application_error(c_stack_info_error, log.error_result(), true);

end full_download_calendar_mfp_sm;

end staging_isp;

/

