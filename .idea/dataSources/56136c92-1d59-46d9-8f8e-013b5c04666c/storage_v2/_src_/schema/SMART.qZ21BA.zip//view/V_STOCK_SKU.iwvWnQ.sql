create view V_STOCK_SKU as
select
    mm.balance_date,
    mm.id_ware,
    w.name as ware_moniker,
    w.article,
    mm.id_sellers,
    s.name_rus as seller_moniker,
    mm.id_department,
    d.moniker as department,
    mm.id_department_sourse,
    ds.moniker as department_sourse,
    mm.stock_type,
    mm.quantity as qty
from
    mks_merchant_stock_data mm
left join
    mdm_sellers_ware w
on
   w.id_ware = mm.id_ware
   and w.status = 1
left join
   mdm_sellers s
on
    s.id_sellers = mm.id_sellers
    and s.status = 1
left join
    mdm_department d
on
    d.id_department = mm.id_department
    and d.status = 1
left join
    mdm_department ds
on
    ds.id_department = mm.id_department_sourse
    and ds.status = 1
/

comment on table V_STOCK_SKU is 'Данные МКС по остаткам товаром мерчантов (merchants/sellers)'
/

comment on column V_STOCK_SKU.BALANCE_DATE is 'Дата остатка'
/

comment on column V_STOCK_SKU.ID_WARE is 'ID товара '
/

comment on column V_STOCK_SKU.WARE_MONIKER is 'Наименование товара'
/

comment on column V_STOCK_SKU.ARTICLE is 'Артикль товара'
/

comment on column V_STOCK_SKU.ID_SELLERS is 'ID продавца (merchant/seller) '
/

comment on column V_STOCK_SKU.SELLER_MONIKER is 'Наименование продавца (merchant/seller)'
/

comment on column V_STOCK_SKU.ID_DEPARTMENT is 'ID подразделения хранения или подразделение получателя'
/

comment on column V_STOCK_SKU.DEPARTMENT is 'Подразделения хранения или подразделение получателя'
/

comment on column V_STOCK_SKU.ID_DEPARTMENT_SOURSE is 'ID подразделения хранения или подразделение отправителя'
/

comment on column V_STOCK_SKU.DEPARTMENT_SOURSE is 'Подразделения хранения или подразделение отправителя'
/

comment on column V_STOCK_SKU.STOCK_TYPE is 'Код типа остатка'
/

comment on column V_STOCK_SKU.QTY is 'Количество товара'
/

