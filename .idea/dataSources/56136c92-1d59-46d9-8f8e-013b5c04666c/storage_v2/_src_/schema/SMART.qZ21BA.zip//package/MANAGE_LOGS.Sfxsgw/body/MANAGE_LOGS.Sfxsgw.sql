create package body manage_logs as

-- Коды ошибок (исключений)
c_illegal_arg_error constant pls_integer := -20001;     -- Некорректные параметры вызова процедуры
c_process_error     constant pls_integer := -20002;     -- Ошибка при выполнении (из-за настроек и т.д.)
c_stack_info_error  constant pls_integer := -20100;     -- Дополнительная информация по ошибке

-- Ошибки возвращаемые в backend
c_ok_text         constant varchar2(4 char) := 'ok';    -- Результат при успешном выполнении
c_ok_code         constant pls_integer :=    200;       -- Код успешного выполнения
c_db_error        constant pls_integer :=    500;

c_eol constant varchar2(1 char) := chr(10);             -- Конец строки

-- Настройки текущей сессии (имеют приоритет над настройками из таблицы adm_settings)
type session_setting_t is record (
    num_value adm_settings.num_value%type,
    str_value adm_settings.str_value%type,
    date_value adm_settings.date_value%type
);
type session_settings_t is table of session_setting_t index by adm_settings.name%type;
g_session_settings session_settings_t;

-- Текущее состояние логирования
g_lgr adm_proc_log%rowtype;                             -- Данные текущего лога выполнения процедуры
g_log_rowid rowid;                                      -- RowID записи текущего лога (если она добавлена в таблицу)
g_log_debug_level integer;                              -- Текущий уровень логирования (из настройки debug_info_level)
g_log_dbms_output boolean;                              -- Признак вывода сообщений лога через dbms_output

-- Чтение числовой настройки
function get_number
(
    p_name  adm_settings.name%type
) return adm_settings.num_value%type is
v_value adm_settings.num_value%type;
begin
    if g_session_settings.exists( p_name) then
        v_value := g_session_settings( p_name).num_value;
    else
        select
            num_value
        into
            v_value
        from
            adm_settings
        where
            name = lower(p_name);
    end if;

    return v_value;
exception
    when no_data_found then
        return null;
end get_number;

-- Добавляет строку в текст лога (в g_lgr.debug_info)
procedure proc_log_add_line(
    o_log_time in out nocopy timestamp with time zone,  -- Время для вывода в строке (текущее если не указано)
    p_text varchar2                                     -- Текст строки
)
is
begin
    if o_log_time is null then
        o_log_time := systimestamp;
    end if;
    g_lgr.debug_info :=
        case when g_lgr.debug_info is not null then
            g_lgr.debug_info || c_eol
        end
        || to_char( o_log_time, 'hh24:mi:ss:ff2 ') || p_text
    ;
exception when others then
    raise_application_error(
        c_stack_info_error,
        'Error on add log line ('
            || ' p_text="' || substr( p_text, 1, 500)
            || case when length( p_text) > 500 then
                    '..." (first 500 chars from ' || length( p_text) || ')'
                else
                    '"'
                end
            || ').',
        true
    );
end proc_log_add_line;

-- Инициализация при начале логирования новой записи
procedure proc_log_init(
    p_proc_name varchar2 := null,   -- Имя пакета.процедуры.переменной
    p_proc_param varchar2 := null  -- Параметры процедуры
)
is
begin
    g_lgr.proc_log_id   := adm_proc_debug_log_id_seq.nextval;
    g_lgr.os_user       := sys_context( 'userenv', 'os_user');
    g_lgr.proc_start    := systimestamp;
    g_lgr.proc_name     := substr( p_proc_name, 1, 200);
    g_lgr.proc_param    := substr( p_proc_param, 1, 4000);   
exception when others then
    raise_application_error(
        c_stack_info_error,
        'Error on initialize new log record.',
        true
    );
end proc_log_init;

-- Возвращает необходимость логирования
function proc_log_enabled(
    p_is_error boolean := null                          -- Логирование ошибки (по умолчанию нет)
)
return boolean
is
begin
    if g_log_debug_level is null then
        g_log_debug_level := get_number( p_name => 'debug_info_level');
    end if;
    return
        -- Была ошибка или протоколируем все случаи
        g_log_debug_level = 1 and p_is_error
        or g_log_debug_level = 2
    ;
exception when others then
    raise_application_error(
        c_stack_info_error,
        'Error on check log enabled.',
        true
    );
end proc_log_enabled;

-- Выводит строку лога через dbms_output
procedure proc_log_out_line(
    p_text varchar2,                                    -- Текст строки
    p_log_time timestamp with time zone := null         -- Время для вывода в строке (текущее если не указано)
)
is

    v_log_time_str varchar2(50);                        -- Строка со временем для лога

begin
    v_log_time_str := to_char( coalesce( p_log_time, systimestamp), 'hh24:mi:ss:ff2 ');
    dbms_output.put_line( v_log_time_str || p_text);
exception when others then
    raise_application_error(
        c_stack_info_error,
        'Error on output log line ('
            || ' p_text="' || substr( p_text, 1, 500)
            || case when length( p_text) > 500 then
                    '..." (first 500 chars from ' || length( p_text) || ')'
                else
                    '"'
                end
            || ').',
        true
    );
end proc_log_out_line;

-- Сохраняет данные текущего лога выполнения процедуры (g_lgr) в таблицу в автономной транзакции
procedure proc_log_save
is

    pragma autonomous_transaction;

begin
    if g_log_rowid is null then
        insert into
            adm_proc_log
        values
            g_lgr
        returning
            rowid
        into
            g_log_rowid;
    else
        update
            adm_proc_log t
        set
            t.proc_param    = g_lgr.proc_param,
            t.proc_end      = g_lgr.proc_end,
            t.debug_info    = g_lgr.debug_info,
            t.error_code    = g_lgr.error_code,
            t.error_text    = g_lgr.error_text
        where
            t.rowid = g_log_rowid
        ;
    end if;
    commit;
exception when others then
    raise_application_error(
        c_stack_info_error,
        'Error on save log record.',
        true
    );
end proc_log_save;

-- Возвращает необходимость вывода лога через dbms_output
function proc_log_dbout_enabled
return boolean
is
begin
    if g_log_dbms_output is null then
        g_log_dbms_output := get_log_dbms_output_flag();
    end if;
    return g_log_dbms_output;
exception when others then
    raise_application_error(
        c_stack_info_error,
        'Error on check log dbms_output enabled.',
        true
    );
end proc_log_dbout_enabled;

-- Обработка исключений в процедурах логирования верхнего уровня
-- (гасим исключение и пытаемся как-то вывести сообщение об ошибке)
procedure proc_log_on_error(
    p_error_message varchar2
)
is

    v_cur_time timestamp with time zone;                -- Текущее время для строки лога

begin

    -- Добавляем сообщение об ошибке в лог (если логирование выполняется)
    begin
        if g_lgr.debug_info is not null then
            proc_log_add_line(
                o_log_time  => v_cur_time,
                p_text      => p_error_message
            );
        end if;
    exception when others then
        null;
    end;

    -- Выводим сообщение об ошибке через dbms_output
    begin
        proc_log_out_line(
            p_log_time  => v_cur_time,
            p_text      => p_error_message
        );
    exception when others then
        null;
    end;
end proc_log_on_error;

-- Устанавливает признак вывода сообщений лога через dbms_output
procedure set_log_dbms_output_flag(
    p_log_dbms_output_flag boolean := null      -- Признак вывода сообщений лога через dbms_output (по умолчанию нет)
)
is
begin
    dbms_session.set_context(
        namespace   => 'clientcontext',
        attribute   => 'log_dbms_output',
        value       => case when p_log_dbms_output_flag then '1' else '0' end
    );
end set_log_dbms_output_flag;

-- Возвращает признак вывода сообщений лога через dbms_output (true если да, false если нет)
function get_log_dbms_output_flag
return boolean
is
begin
    return coalesce( sys_context( 'clientcontext', 'log_dbms_output'), '0') != '0';
end get_log_dbms_output_flag;

-- Начало протоколирования выполнения процедуры
procedure proc_log_start(
    p_proc_name varchar2 := null,   -- Имя пакета.процедуры.переменной
    p_proc_param varchar2 := null,  -- Параметры процедуры
    p_value varchar2 := null        -- Возможная первая запись о начале выполнения
)
is
begin

    -- Начинаем логирование
    if g_lgr.debug_info is null then

        -- Инициализация
        proc_log_init(
            p_proc_name     => p_proc_name,
            p_proc_param    => p_proc_param
        );
        proc_log_add_line(
            o_log_time      => g_lgr.proc_start,
            p_text          => coalesce( p_value, 'Start ' || p_proc_name)
        );

        -- Сохраняем запись в таблицу если логирование разрешено
        if proc_log_enabled() then
            proc_log_save();
        end if;

        -- Выводим через dbms_output если вывод разрешен
        if proc_log_dbout_enabled() then
            proc_log_out_line(
                p_log_time  => g_lgr.proc_start,
                p_text      =>
                    'Start ' || p_proc_name
                    || case when p_proc_param is not null then ' (' || p_proc_param || ')' end
                    || case when p_value is not null then ': ' || p_value end
            );
        end if;

    -- Начало выполнения вложенного вызова процедуры
    else
        proc_log_value(
            p_value =>
                coalesce( p_value, 'Start: ' || p_proc_name)
                || case when p_proc_param is not null then ' (' || p_proc_param || ')' end
                || case when p_value is not null then ': ' || p_value end
        );
    end if;
exception when others then
    proc_log_on_error( 'manage_logs.proc_log_start error:' || c_eol || dbms_utility.format_error_stack);
end proc_log_start;

-- Добавление записи в лог выполнения процедуры
procedure proc_log_value(
    p_value varchar2 := null        -- Значение для протоколирования
)
is

    v_cur_time timestamp with time zone;                -- Текущее время для строки лога

begin
    if g_lgr.debug_info is not null then
        proc_log_add_line(
            o_log_time      => v_cur_time,
            p_text          => p_value
        );
    end if;
    if proc_log_dbout_enabled() then
        proc_log_out_line(
            p_log_time      => v_cur_time,
            p_text          => p_value
        );
    end if;
exception when others then
    proc_log_on_error( 'manage_logs.proc_log_value error:' || c_eol || dbms_utility.format_error_stack);
end proc_log_value;

-- Завершение выполнения процедуры
procedure proc_log_end(
    o_high_level_log_error out varchar2,    -- Лог формируемый для процедуры верхнего уровня
    p_proc_name varchar2 := null,           -- Имя пакета.процедуры.переменной
    p_proc_param varchar2 := null,          -- Параметры процедуры
    p_value varchar2 := null,               -- Возможная первая запись о начале выполнения
    p_error_code number := null,            -- Код ошибки
    p_error_text varchar2 := null           -- Текст ошибки
)
is

    v_cur_time timestamp with time zone;                -- Текущее время для строки лога
    v_is_error boolean :=                               -- Признак завершения с ошибкой
        coalesce( p_error_code != c_ok_code, false)
    ;
    v_is_finish_log boolean;                            -- Признак закрытия текущей записи лога

    v_high_level_log varchar2(32767);                   -- Формируемая лог для верхнеуровневой процедуры. Добавляется префикс к p_error_text, если это ошибка
begin
    -- Не закрываем лог если имя завершающейся процедуры отличается от имени процедуры, для которой лог был открыт
    v_is_finish_log := coalesce( p_proc_name = g_lgr.proc_name, true);

    -- Завершение выполнения процедуры верхнего уровня
    if v_is_finish_log then
        if proc_log_enabled( p_is_error => v_is_error) then

            -- Если логирование не ведется, начинаем его этой записью
            if g_lgr.debug_info is null then
                proc_log_init(
                    p_proc_name     => p_proc_name,
                    p_proc_param    => p_proc_param                    
                );
                v_cur_time := g_lgr.proc_start;
            else
                -- Обогащаем информацию о завершающейся процедуре
                g_lgr.proc_param    := coalesce( g_lgr.proc_param, p_proc_param);
                v_cur_time := systimestamp;
            end if;

            v_high_level_log := p_error_text;

            -- Если ошибка, то добавляем префикс
            if(v_is_error) then
                -- Формирование префикса верхнего уровня
                v_high_level_log :=
                    'DB Exception! Log id: ' || coalesce(to_char(g_lgr.proc_log_id), 'undefined')
                    || '. Check procedure ' || g_lgr.proc_name
                    || v_high_level_log;

                o_high_level_log_error := v_high_level_log;
            end if;

            -- Сохраняем параметры завершения процедуры
            g_lgr.proc_end      := v_cur_time;
            g_lgr.error_code    := p_error_code;
            g_lgr.error_text    := substr(v_high_level_log, 1, 4000);

            -- Добавляем строку в текстовый лог
            proc_log_add_line(
                o_log_time      => v_cur_time,
                p_text          =>
                    coalesce( p_value, 'Finish ' || g_lgr.proc_name)
                    || case when v_is_error then ': error ' || to_char( p_error_code) end
            );

            -- Сохраняем лог в таблицу
            proc_log_save();
        end if;

        if proc_log_dbout_enabled() then
            proc_log_out_line(
                p_log_time  => v_cur_time,
                p_text      =>
                    'Finish ' || coalesce( p_proc_name, g_lgr.proc_name, 'procedure')
                    || case when v_is_error or p_error_text is not null then
                            case when v_is_error then
                                ': error ' || to_char( p_error_code)
                                || case when p_error_text is not null then ' ' || p_error_text end
                            else
                                ': result: ' || p_error_text
                            end
                        end
                    || case when p_value is not null then ': ' || p_value end
            );
        end if;

        -- Очищаем состояние при завершении логирования текущей записи
        g_lgr               := null;
        g_log_rowid         := null;
        g_log_debug_level   := null;
        g_log_dbms_output   := null;

    -- Завершение выполнения вложенного вызова процедуры
    else
        proc_log_value(
            p_value =>
                coalesce( p_value, 'End: ' || p_proc_name)
                || case when v_is_error or p_error_text is not null then
                        case when v_is_error then
                            ': error ' || to_char( p_error_code)
                            || case when p_error_text is not null then ' ' || p_error_text end
                        else
                            ': result: ' || p_error_text
                        end
                    end
                || case when p_value is not null then ': ' || p_value end
        );
    end if;

exception when others then
    proc_log_on_error( 'manage_logs.proc_log_end error:' || c_eol || dbms_utility.format_error_stack);
end proc_log_end;

-- Функция возвращает true если имя процедуры = той, в которой лог открыт, т.е. верхнеуровневой
function proc_log_is_top(p_proc_name in varchar2) return boolean is begin
  return coalesce(p_proc_name = g_lgr.proc_name, true);
end;

end;
/

